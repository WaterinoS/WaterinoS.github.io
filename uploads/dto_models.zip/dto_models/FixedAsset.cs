﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Newtonsoft.Json;
using Noris.LCS.WebApi.Globals.Contracts;

namespace Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts
{
    /// <summary>
    /// API GET Customer/Pantheon/Majetek QUERY parameters
    /// </summary>
    public class FixedAssetGetRequest : BaseItem
    {
        /// <summary>
        /// CZ: Id majetku.
        /// </summary>
        [JsonProperty(PropertyName = "mistnostId")]
        public int? MistnostId { get => _MistnostId; set => Set(ref _MistnostId, value); }
        private int? _MistnostId;
        public bool ShouldSerializeMistnostId() { return IsPropertyChanged(nameof(MistnostId)); }

        /// <summary>
        /// CZ: Místnost.
        /// </summary>
        [JsonProperty(PropertyName = "mistnost")]
        public RoomGetRequest Mistnost { get => _Mistnost; set => Set(ref _Mistnost, value); }
        private RoomGetRequest _Mistnost;
        public bool ShouldSerializeMistnost() { return IsPropertyChanged(nameof(Mistnost)); }
        /// <summary>
        /// CZ: Zodpovědná osoba.
        /// </summary>
        [JsonProperty(PropertyName = "zodpovednaOsoba")]
        public EmployeeGetRequest ZodpovednaOsoba { get => _ZodpovednaOsoba; set => Set(ref _ZodpovednaOsoba, value); }
        private EmployeeGetRequest _ZodpovednaOsoba;
        public bool ShouldSerializeZodpovednaOsoba() { return IsPropertyChanged(nameof(ZodpovednaOsoba)); }

        [JsonProperty(PropertyName = "zodpovednaOsobaId")]
        public int? ZodpovednaOsobaId { get => _ZodpovednaOsobaId; set => Set(ref _ZodpovednaOsobaId, value); }
        private int? _ZodpovednaOsobaId;
        public bool ShouldSerializeZodpovednaOsobaId() { return IsPropertyChanged(nameof(ZodpovednaOsobaId)); }

        [JsonProperty(PropertyName = "typMajetku")]
        public int? TypMajetku { get => _TypMajetku; set => Set(ref _TypMajetku, value); }
        private int? _TypMajetku;
        public bool ShouldSerializeTypMajetku() { return IsPropertyChanged(nameof(TypMajetku)); }
    }

    /// <summary>
    /// API GET Customer/Pantheon/Majetek RESPONSE
    /// API GET Customer/Pantheon/Majetek/{type}/{id} RESPONSE
    /// </summary>
    public class FixedAssetGetResponse
    {
        /// <summary>
        /// CZ: Kolekce organizací.
        /// </summary>
        public List<FixedAssetGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class FixedAssetGetResponseElement : BaseItem
    {
        /// <summary>
        /// CZ: Číslo záznamu.
        /// </summary> 
        [JsonIgnore]
        [JsonProperty(PropertyName = "recordNumber")]
        public int? RecordNumber { get => _RecordNumber; set => Set(ref _RecordNumber, value); }
        private int? _RecordNumber;
        public bool ShouldSerializeRecordNumber() { return IsPropertyChanged(nameof(RecordNumber)); }

        /// <summary>
        /// CZ: Číslo útvaru.
        /// </summary>
        [JsonProperty(PropertyName = "utvarId")]
        public int? UtvarId { get => _UtvarId; set => Set(ref _UtvarId, value); }
        private int? _UtvarId;
        public bool ShouldSerializeUtvarId() { return IsPropertyChanged(nameof(UtvarId)); }
        /// <summary>
        /// CZ: Stav majetku: 
        ///     1 - Převzat do evidence, 
        ///     2 - Zařazen, 
        ///     3 - Aktivní, 
        ///     4 - Připraven k vyřazení, 
        ///     5 - Vyřazen, 
        ///     6 - Převeden, 
        ///     7 - Stornován,
        ///     8 - Předimportován,
        ///     9 - Předzpracován.
        /// </summary>
        [JsonProperty(PropertyName = "stav")]
        public int? Stav { get => _Stav; set => Set(ref _Stav, value); }
        private int? _Stav;
        public bool ShouldSerializeStav() { return IsPropertyChanged(nameof(Stav)); }
        /// <summary>
        /// CZ: Datum pořízení.
        /// </summary>
        [JsonProperty(PropertyName = "datumPorizeni")]
        public DateTime? DatumPorizeni { get => _DatumPorizeni; set => Set(ref _DatumPorizeni, value); }
        private DateTime? _DatumPorizeni;
        public bool ShouldSerializeDatumPorizeni() { return IsPropertyChanged(nameof(DatumPorizeni)); }
        /// <summary>
        /// CZ: Datum vyřazení.
        /// </summary>
        [JsonProperty(PropertyName = "datumVyrazeni")]
        public DateTime? DatumVyrazeni { get => _DatumVyrazeni; set => Set(ref _DatumVyrazeni, value); }
        private DateTime? _DatumVyrazeni;
        public bool ShouldSerializeDatumVyrazeni() { return IsPropertyChanged(nameof(DatumVyrazeni)); }
        /// <summary>
        /// CZ: Datum zařazení.
        /// </summary>
        [JsonProperty(PropertyName = "datumZarazeni")]
        public DateTime? DatumZarazeni { get => _DatumZarazeni; set => Set(ref _DatumZarazeni, value); }
        private DateTime? _DatumZarazeni;
        public bool ShouldSerializeDatumZarazeni() { return IsPropertyChanged(nameof(DatumZarazeni)); }
        /// <summary>
        /// CZ: Inventární číslo.
        /// </summary>
        [JsonProperty(PropertyName = "inventarniCislo")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string InventarniCislo { get => _InventarniCislo; set => Set(ref _InventarniCislo, value); }
        private string _InventarniCislo;
        public bool ShouldSerializeInventarniCislo() { return IsPropertyChanged(nameof(InventarniCislo)); }

        /// <summary>
        /// CZ: Id majetku.
        /// </summary>
        [JsonProperty(PropertyName = "majetekId")]
        public int? MajetekId { get => _MajetekId; set => Set(ref _MajetekId, value); }
        private int? _MajetekId;
        public bool ShouldSerializeMajetekId() { return IsPropertyChanged(nameof(MajetekId)); }
        /// <summary>
        /// CZ: Název.
        /// </summary>
        [JsonProperty(PropertyName = "nazev")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Nazev { get => _Nazev; set => Set(ref _Nazev, value); }
        private string _Nazev;
        public bool ShouldSerializeNazev() { return IsPropertyChanged(nameof(Nazev)); }
        /// <summary>
        /// CZ: Výrobní číslo.
        /// </summary>
        [JsonProperty(PropertyName = "vyrobniCislo")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string VyrobniCislo { get => _VyrobniCislo; set => Set(ref _VyrobniCislo, value); }
        private string _VyrobniCislo;
        public bool ShouldSerializeVyrobniCislo() { return IsPropertyChanged(nameof(VyrobniCislo)); }
        /// <summary>
        /// CZ: Pořizovací cena.
        /// </summary>
        [JsonProperty(PropertyName = "porizovaciCena")]
        public decimal? PorizovaciCena { get => _PorizovaciCena; set => Set(ref _PorizovaciCena, value); }
        private decimal? _PorizovaciCena;
        public bool ShouldSerializePorizovaciCena() { return IsPropertyChanged(nameof(PorizovaciCena)); }
        /// <summary>
        /// CZ: Aktuální cena.
        /// </summary>
        [JsonProperty(PropertyName = "aktualniCena")]
        public decimal? AktualniCena { get => _AktualniCena; set => Set(ref _AktualniCena, value); }
        private decimal? _AktualniCena;
        public bool ShouldSerializeAktualniCena() { return IsPropertyChanged(nameof(AktualniCena)); }

        /// <summary>
        /// CZ: Místnost.
        /// </summary>
        [JsonProperty(PropertyName = "mistnost")]
        public RoomGetResponseElement Mistnost { get => _Mistnost; set => Set(ref _Mistnost, value); }
        private RoomGetResponseElement _Mistnost;
        public bool ShouldSerializeMistnost() { return IsPropertyChanged(nameof(Mistnost)); }
        /// <summary>
        /// CZ: Zodpovědná osoba.
        /// </summary>
        [JsonProperty(PropertyName = "zodpovednaOsoba")]
        public EmployeeGetResponseElement ZodpovednaOsoba { get => _ZodpovednaOsoba; set => Set(ref _ZodpovednaOsoba, value); }
        private EmployeeGetResponseElement _ZodpovednaOsoba;
        public bool ShouldSerializeZodpovednaOsoba() { return IsPropertyChanged(nameof(ZodpovednaOsoba)); }
    }
}
