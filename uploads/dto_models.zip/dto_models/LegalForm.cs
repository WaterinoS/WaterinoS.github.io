﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Newtonsoft.Json;
using Noris.LCS.WebApi.Globals.Contracts;

namespace Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts
{
    /// <summary>
    /// API GET Customer/Pantheon/PravniForma RESPONSE
    /// </summary>
    public class LegalFormGetResponse
    {
        /// <summary>
        /// CZ: Kolekce právních forem
        /// </summary>
        public List<LegalFormGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class LegalFormGetResponseElement : BaseItem
    {
        [JsonProperty(PropertyName = "kod")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Kod { get => _Kod; set => Set(ref _Kod, value); }
        private string _Kod;
        public bool ShouldSerializeKod() { return IsPropertyChanged(nameof(Kod)); }

        [JsonProperty(PropertyName = "kodRES")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string KodRES { get => _KodRES; set => Set(ref _KodRES, value); }
        private string _KodRES;
        public bool ShouldSerializeKodRES() { return IsPropertyChanged(nameof(KodRES)); }

        [JsonProperty(PropertyName = "typ")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Typ { get => _Typ; set => Set(ref _Typ, value); }
        private string _Typ;
        public bool ShouldSerializeTyp() { return IsPropertyChanged(nameof(Typ)); }

        [JsonProperty(PropertyName = "popis")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Popis { get => _Popis; set => Set(ref _Popis, value); }
        private string _Popis;
        public bool ShouldSerializePopis() { return IsPropertyChanged(nameof(Popis)); }
    }
}
