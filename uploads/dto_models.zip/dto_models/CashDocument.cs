﻿using System;
using System.Collections.Generic;
using System.Text;

using Newtonsoft.Json;

using Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts;
using Noris.LCS.WebApi.Globals.Contracts;

namespace Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts
{
    /// <summary>
    /// API GET Customer/Pantheon/PokladniDoklad RESPONSE
    /// </summary>
    public class CashDocumentGetResponse
    {
        /// <summary>
        /// CZ: Kolekce pokladních dokladů.
        /// </summary>
        public List<CashDocumentGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class CashDocumentGetResponseElement : BaseItem
    {
        [JsonIgnore]
        [JsonProperty(PropertyName = "recordNumber")]
        public int? RecordNumber { get => _RecordNumber; set => Set(ref _RecordNumber, value); }
        private int? _RecordNumber;
        private bool ShouldSerializeRecordNumber() { return IsPropertyChanged(nameof(RecordNumber)); }

        [JsonProperty(PropertyName = "cenaCelkem")]
        public decimal? CenaCelkem { get => _CenaCelkem; set => Set(ref _CenaCelkem, value); }
        private decimal? _CenaCelkem;
        private bool ShouldSerializeCenaCelkem() { return IsPropertyChanged(nameof(CenaCelkem)); }

        [JsonIgnore]
        [JsonProperty(PropertyName = "cisloPoradace")]
        public int? CisloPoradace { get => _CisloPoradace; set => Set(ref _CisloPoradace, value); }
        private int? _CisloPoradace;
        private bool ShouldSerializeCisloPoradace() { return IsPropertyChanged(nameof(CisloPoradace)); }

        [JsonProperty(PropertyName = "datumDuzp")]
        public DateTime? DatumDuzp { get => _DatumDuzp; set => Set(ref _DatumDuzp, value); }
        private DateTime? _DatumDuzp;
        private bool ShouldSerializeDatumDuzp() { return IsPropertyChanged(nameof(DatumDuzp)); }

        [JsonProperty(PropertyName = "datumPorizeni")]
        public DateTime? DatumPorizeni { get => _DatumPorizeni; set => Set(ref _DatumPorizeni, value); }
        private DateTime? _DatumPorizeni;
        private bool ShouldSerializeDatumPorizeni() { return IsPropertyChanged(nameof(DatumPorizeni)); }

        [JsonProperty(PropertyName = "organizaceSubjekt")]
        public OrganizaceGetResponseElement OrganizaceSubjekt { get => _OrganizaceSubjekt; set => Set(ref _OrganizaceSubjekt, value); }
        private OrganizaceGetResponseElement _OrganizaceSubjekt;
        private bool ShouldSerializeOrganizaceSubjekt() { return IsPropertyChanged(nameof(OrganizaceSubjekt)); }

        [JsonProperty(PropertyName = "pokladniDokladId")]
        public int? PokladniDokladId { get => _PokladniDokladId; set => Set(ref _PokladniDokladId, value); }
        private int? _PokladniDokladId;
        private bool ShouldSerializePokladniDokladId() { return IsPropertyChanged(nameof(PokladniDokladId)); }

        [JsonProperty(PropertyName = "pokladniDokladIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PokladniDokladIdEx { get => _PokladniDokladIdEx; set => Set(ref _PokladniDokladIdEx, value); }
        private string _PokladniDokladIdEx;
        private bool ShouldSerializePokladniDokladIdEx() { return IsPropertyChanged(nameof(PokladniDokladIdEx)); }

        [JsonProperty(PropertyName = "poznamka")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Poznamka { get => _Poznamka; set => Set(ref _Poznamka, value); }
        private string _Poznamka;
        private bool ShouldSerializePoznamka() { return IsPropertyChanged(nameof(Poznamka)); }

        [JsonProperty(PropertyName = "referenceSubjektu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string ReferenceSubjektu { get => _ReferenceSubjektu; set => Set(ref _ReferenceSubjektu, value); }
        private string _ReferenceSubjektu;
        private bool ShouldSerializeReferenceSubjektu() { return IsPropertyChanged(nameof(ReferenceSubjektu)); }

        [JsonProperty(PropertyName = "stav")]
        public int? Stav { get => _Stav; set => Set(ref _Stav, value); }
        private int? _Stav;
        private bool ShouldSerializeStav() { return IsPropertyChanged(nameof(Stav)); }

        [JsonProperty(PropertyName = "typ")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Typ { get => _Typ; set => Set(ref _Typ, value); }
        private string _Typ;
        private bool ShouldSerializeTyp() { return IsPropertyChanged(nameof(Typ)); }

        [JsonProperty(PropertyName = "ucelPlatby")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string UcelPlatby { get => _UcelPlatby; set => Set(ref _UcelPlatby, value); }
        private string _UcelPlatby;
        private bool ShouldSerializeUcelPlatby() { return IsPropertyChanged(nameof(UcelPlatby)); }

        [JsonProperty(PropertyName = "zpusobUhrady")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string ZpusobUhrady { get => _ZpusobUhrady; set => Set(ref _ZpusobUhrady, value); }
        private string _ZpusobUhrady;
        private bool ShouldSerializeZpusobUhrady() { return IsPropertyChanged(nameof(ZpusobUhrady)); }

        [JsonProperty(PropertyName = "polozky")]
        public List<CashDocumentItem> Polozky { get => _Polozky; set => Set(ref _Polozky, value); }
        private List<CashDocumentItem> _Polozky;
        private bool ShouldSerializePolozky() { return IsPropertyChanged(nameof(Polozky)); }
    }

    public class CashDocumentGetRequest : BaseItem
    {
        [JsonProperty(PropertyName = "pokladniDokladId")]
        public int? PokladniDokladId { get => _PokladniDokladId; set => Set(ref _PokladniDokladId, value); }
        private int? _PokladniDokladId;
        private bool ShouldSerializePokladniDokladId() { return IsPropertyChanged(nameof(PokladniDokladId)); }

        [JsonProperty(PropertyName = "pokladniDokladIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PokladniDokladIdEx { get => _PokladniDokladIdEx; set => Set(ref _PokladniDokladIdEx, value); }
        private string _PokladniDokladIdEx;
        private bool ShouldSerializePokladniDokladIdEx() { return IsPropertyChanged(nameof(PokladniDokladIdEx)); }

        [JsonProperty(PropertyName = "organizace")]
        public OrganizaceSearch Organizace { get => _Organizace; set => Set(ref _Organizace, value); }
        private OrganizaceSearch _Organizace;
        private bool ShouldSerializeOrganizace() { return IsPropertyChanged(nameof(Organizace)); }

        [JsonProperty(PropertyName = "poradacId")]
        public int? PoradacId { get => _PoradacId; set => Set(ref _PoradacId, value); }
        private int? _PoradacId;
        private bool ShouldSerializePoradacId() { return IsPropertyChanged(nameof(PoradacId)); }
    }

    public class CashDocumentPostPutRequest : BaseItem
    {
        [JsonProperty(PropertyName = "referenceSubjektu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string ReferenceSubjektu { get => _ReferenceSubjektu; set => Set(ref _ReferenceSubjektu, value); }
        private string _ReferenceSubjektu;
        private bool ShouldSerializeReferenceSubjektu() { return IsPropertyChanged(nameof(ReferenceSubjektu)); }

        [JsonRequired]
        [JsonProperty(PropertyName = "cisloPoradace")]
        public int? CisloPoradace { get => _CisloPoradace; set => Set(ref _CisloPoradace, value); }
        private int? _CisloPoradace;
        private bool ShouldSerializeCisloPoradace() { return IsPropertyChanged(nameof(CisloPoradace)); }

        [JsonProperty(PropertyName = "cisloDokladuEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string CisloDokladuEx { get => _CisloDokladuEx; set => Set(ref _CisloDokladuEx, value); }
        private string _CisloDokladuEx;
        private bool ShouldSerializeCisloDokladuEx() { return IsPropertyChanged(nameof(CisloDokladuEx)); }

        [JsonProperty(PropertyName = "datumDuzp")]
        public DateTime? DatumDuzp { get => _DatumDuzp; set => Set(ref _DatumDuzp, value); }
        private DateTime? _DatumDuzp;
        private bool ShouldSerializeDatumDuzp() { return IsPropertyChanged(nameof(DatumDuzp)); }

        [JsonProperty(PropertyName = "datumPorizeni")]
        public DateTime? DatumPorizeni { get => _DatumPorizeni; set => Set(ref _DatumPorizeni, value); }
        private DateTime? _DatumPorizeni;
        private bool ShouldSerializeDatumPorizeni() { return IsPropertyChanged(nameof(DatumPorizeni)); }

        [JsonProperty(PropertyName = "pokladniDokladIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PokladniDokladIdEx { get => _PokladniDokladIdEx; set => Set(ref _PokladniDokladIdEx, value); }
        private string _PokladniDokladIdEx;
        private bool ShouldSerializePokladniDokladIdEx() { return IsPropertyChanged(nameof(PokladniDokladIdEx)); }

        [JsonProperty(PropertyName = "organizaceSubjekt")]
        public OrganizaceGetResponseElement OrganizaceSubjekt { get => _OrganizaceSubjekt; set => Set(ref _OrganizaceSubjekt, value); }
        private OrganizaceGetResponseElement _OrganizaceSubjekt;
        private bool ShouldSerializeOrganizaceSubjekt() { return IsPropertyChanged(nameof(OrganizaceSubjekt)); }

        [JsonProperty(PropertyName = "poznamka")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Poznamka { get => _Poznamka; set => Set(ref _Poznamka, value); }
        private string _Poznamka;
        private bool ShouldSerializePoznamka() { return IsPropertyChanged(nameof(Poznamka)); }

        [JsonProperty(PropertyName = "ucelPlatby")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string UcelPlatby { get => _UcelPlatby; set => Set(ref _UcelPlatby, value); }
        private string _UcelPlatby;
        private bool ShouldSerializeUcelPlatby() { return IsPropertyChanged(nameof(UcelPlatby)); }

        [JsonProperty(PropertyName = "zpusobUhrady")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string ZpusobUhrady { get => _ZpusobUhrady; set => Set(ref _ZpusobUhrady, value); }
        private string _ZpusobUhrady;
        private bool ShouldSerializeZpusobUhrady() { return IsPropertyChanged(nameof(ZpusobUhrady)); }

        [JsonProperty(PropertyName = "typ")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Typ { get => _Typ; set => Set(ref _Typ, value); }
        private string _Typ;
        private bool ShouldSerializeTyp() { return IsPropertyChanged(nameof(Typ)); }

        [JsonProperty(PropertyName = "polozky")]
        public List<CashDocumentItem> Polozky { get => _Polozky; set => Set(ref _Polozky, value); }
        private List<CashDocumentItem> _Polozky;
        private bool ShouldSerializePolozky() { return IsPropertyChanged(nameof(Polozky)); }

        [JsonProperty(PropertyName = "maKodDphNaNekterePolozce")]
        public bool? MaKodDphNaNekterePolozce { get => _MaKodDphNaNekterePolozce; set => Set(ref _MaKodDphNaNekterePolozce, value); }
        private bool? _MaKodDphNaNekterePolozce;
        private bool ShouldSerializeMaKodDphNaNekterePolozce() { return IsPropertyChanged(nameof(MaKodDphNaNekterePolozce)); }

        [JsonIgnore]
        public OrganizacePostPutResponse organizaceSubjekt;
    }

    public class CashDocumentPostPutResponse : CashDocumentGetResponseElement
    {
        /// <summary>
        /// CZ: Chybové hlášky
        /// </summary>
        [JsonProperty(PropertyName = "errors")]
        public List<string> errors;
    }

    public class CashDocumentItem : BaseItem
    {
        [JsonProperty(PropertyName = "cenaCelkem")]
        public decimal? CenaCelkem { get => _CenaCelkem; set => Set(ref _CenaCelkem, value); }
        private decimal? _CenaCelkem;
        private bool ShouldSerializeCenaCelkem() { return IsPropertyChanged(nameof(CenaCelkem)); }

        [JsonProperty(PropertyName = "cenaJednotkova")]
        public decimal? CenaJednotkova { get => _CenaJednotkova; set => Set(ref _CenaJednotkova, value); }
        private decimal? _CenaJednotkova;
        private bool ShouldSerializeCenaJednotkova() { return IsPropertyChanged(nameof(CenaJednotkova)); }

        [JsonProperty(PropertyName = "cenaZaklad")]
        public decimal? CenaZaklad { get => _CenaZaklad; set => Set(ref _CenaZaklad, value); }
        private decimal? _CenaZaklad;
        private bool ShouldSerializeCenaZaklad() { return IsPropertyChanged(nameof(CenaZaklad)); }

        [JsonProperty(PropertyName = "dphCelkem")]
        public decimal? DphCelkem { get => _DphCelkem; set => Set(ref _DphCelkem, value); }
        private decimal? _DphCelkem;
        private bool ShouldSerializeDphCelkem() { return IsPropertyChanged(nameof(DphCelkem)); }

        [JsonProperty(PropertyName = "kodDph")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string KodDph { get => _KodDph; set => Set(ref _KodDph, value); }
        private string _KodDph;
        private bool ShouldSerializeKodDph() { return IsPropertyChanged(nameof(KodDph)); }

        [JsonProperty(PropertyName = "nazev")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Nazev { get => _Nazev; set => Set(ref _Nazev, value); }
        private string _Nazev;
        private bool ShouldSerializeNazev() { return IsPropertyChanged(nameof(Nazev)); }

        [JsonProperty(PropertyName = "pocet")]
        public decimal? Pocet { get => _Pocet; set => Set(ref _Pocet, value); }
        private decimal? _Pocet;
        private bool ShouldSerializePocet() { return IsPropertyChanged(nameof(Pocet)); }

        [JsonIgnore]
        [JsonProperty(PropertyName = "sazbaDph")]
        public int? SazbaDph { get => _SazbaDph; set => Set(ref _SazbaDph, value); }
        private int? _SazbaDph;
        private bool ShouldSerializeSazbaDph() { return IsPropertyChanged(nameof(SazbaDph)); }

        [JsonProperty(PropertyName = "hrazenyDokladId")]
        public int? HrazenyDokladId { get => _HrazenyDokladId; set => Set(ref _HrazenyDokladId, value); }
        private int? _HrazenyDokladId;
        private bool ShouldSerializeHrazenyDokladId() { return IsPropertyChanged(nameof(HrazenyDokladId)); }

        [JsonIgnore]
        [JsonProperty(PropertyName = "hrazenyDokladIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string HrazenyDokladIdEx { get => _HrazenyDokladIdEx; set => Set(ref _HrazenyDokladIdEx, value); }
        private string _HrazenyDokladIdEx;
        private bool ShouldSerializeHrazenyDokladIdEx() { return IsPropertyChanged(nameof(HrazenyDokladIdEx)); }

        [JsonProperty(PropertyName = "parovaciZnak")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string ParovaciZnak { get => _ParovaciZnak; set => Set(ref _ParovaciZnak, value); }
        private string _ParovaciZnak;
        private bool ShouldSerializeParovaciZnak() { return IsPropertyChanged(nameof(ParovaciZnak)); }
    }
}
