﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Newtonsoft.Json;
using Noris.LCS.WebApi.Globals.Contracts;

namespace Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts
{
    /// <summary>
    /// API GET Customer/Pantheon/Mistnost QUERY parameters
    /// </summary>
    public class RoomGetRequest : BaseItem
    {
        [JsonProperty(PropertyName = "mistnostCislo")]
        public string MistnostCislo { get => _MistnostCislo; set => Set(ref _MistnostCislo, value); }
        private string _MistnostCislo;
        public bool ShouldSerializeMistnostCislo() { return IsPropertyChanged(nameof(MistnostCislo)); }

        [JsonProperty(PropertyName = "mistnostNazev")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string MistnostNazev { get => _MistnostNazev; set => Set(ref _MistnostNazev, value); }
        private string _MistnostNazev;
        public bool ShouldSerializeMistnostNazev() { return IsPropertyChanged(nameof(MistnostNazev)); }
    }

    /// <summary>
    /// API GET Customer/Pantheon/Mistnost RESPONSE
    /// API GET Customer/Pantheon/Mistnost/{id} RESPONSE
    /// </summary>
    public class RoomGetResponse
    {
        /// <summary>
        /// CZ: Kolekce organizací.
        /// </summary>
        public List<RoomGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class RoomGetResponseElement : BaseItem
    {
        [JsonIgnore]
        [JsonProperty(PropertyName = "recordNumber")]
        public int? RecordNumber { get => _RecordNumber; set => Set(ref _RecordNumber, value); }
        private int? _RecordNumber;
        public bool ShouldSerializeRecordNumber() { return IsPropertyChanged(nameof(RecordNumber)); }

        [JsonProperty(PropertyName = "cislo")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Cislo { get => _Cislo; set => Set(ref _Cislo, value); }
        private string _Cislo;
        public bool ShouldSerializeCislo() { return IsPropertyChanged(nameof(Cislo)); }

        [JsonProperty(PropertyName = "mistnostId")]
        public int? MistnostId { get => _MistnostId; set => Set(ref _MistnostId, value); }
        private int? _MistnostId;
        public bool ShouldSerializeMistnostId() { return IsPropertyChanged(nameof(MistnostId)); }

        [JsonProperty(PropertyName = "nazev")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Nazev { get => _Nazev; set => Set(ref _Nazev, value); }
        private string _Nazev;
        public bool ShouldSerializeNazev() { return IsPropertyChanged(nameof(Nazev)); }

        [JsonProperty(PropertyName = "stav")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Stav { get => _Stav; set => Set(ref _Stav, value); }
        private string _Stav;
        public bool ShouldSerializeStav() { return IsPropertyChanged(nameof(Stav)); }
    }
}
