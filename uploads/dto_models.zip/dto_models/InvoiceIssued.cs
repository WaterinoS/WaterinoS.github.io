﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Noris.LCS.WebApi.Globals.Contracts;

namespace Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts
{
    /// <summary>
    /// API GET Customer/Pantheon/FakturaVydana RESPONSE
    /// </summary>
    public class InvoicesIssuedGetResponse
    {
        /// <summary>
        /// CZ: Kolekce sazeb dph.
        /// </summary>
        public List<InvoicesIssuedGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class InvoicesIssuedGetRequest : BaseItem
    {
        [JsonProperty(PropertyName = "fakturaId")]
        public int? FakturaId { get => _FakturaId; set => Set(ref _FakturaId, value); }
        private int? _FakturaId;
        public bool ShouldSerializeFakturaId() { return IsPropertyChanged(nameof(FakturaId)); }

        [JsonProperty(PropertyName = "fakturaIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string FakturaIdEx { get => _FakturaIdEx; set => Set(ref _FakturaIdEx, value); }
        private string _FakturaIdEx;
        public bool ShouldSerializeFakturaIdEx() { return IsPropertyChanged(nameof(FakturaIdEx)); }

        [JsonProperty(PropertyName = "organizace")]
        public OrganizaceSearch Organizace { get => _Organizace; set => Set(ref _Organizace, value); }
        private OrganizaceSearch _Organizace;
        public bool ShouldSerializeOrganizace() { return IsPropertyChanged(nameof(Organizace)); }

        [JsonProperty(PropertyName = "stav")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Stav { get => _Stav; set => Set(ref _Stav, value); }
        private string _Stav;
        public bool ShouldSerializeStav() { return IsPropertyChanged(nameof(Stav)); }

        [JsonProperty(PropertyName = "stavUhrazenosti")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string StavUhrazenosti { get => _StavUhrazenosti; set => Set(ref _StavUhrazenosti, value); }
        private string _StavUhrazenosti;
        public bool ShouldSerializeStavUhrazenosti() { return IsPropertyChanged(nameof(StavUhrazenosti)); }

        [JsonProperty(PropertyName = "variabilniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string VariabilniSymbol { get => _VariabilniSymbol; set => Set(ref _VariabilniSymbol, value); }
        private string _VariabilniSymbol;
        public bool ShouldSerializeVariabilniSymbol() { return IsPropertyChanged(nameof(VariabilniSymbol)); }

        [JsonProperty(PropertyName = "parovaciSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string ParovaciSymbol { get => _ParovaciSymbol; set => Set(ref _ParovaciSymbol, value); }
        private string _ParovaciSymbol;
        public bool ShouldSerializeParovaciSymbol() { return IsPropertyChanged(nameof(ParovaciSymbol)); }
    }

    public class InvoicesIssuedGetResponseElement : BaseItem
    {
        [JsonProperty(PropertyName = "fakturaId")]
        public int? FakturaId { get => _FakturaId; set => Set(ref _FakturaId, value); }
        private int? _FakturaId;
        public bool ShouldSerializeFakturaId() { return IsPropertyChanged(nameof(FakturaId)); }

        [JsonProperty(PropertyName = "fakturaIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string FakturaIdEx { get => _FakturaIdEx; set => Set(ref _FakturaIdEx, value); }
        private string _FakturaIdEx;
        public bool ShouldSerializeFakturaIdEx() { return IsPropertyChanged(nameof(FakturaIdEx)); }

        [JsonProperty(PropertyName = "stav")]
        public int? Stav { get => _Stav; set => Set(ref _Stav, value); }
        private int? _Stav;
        public bool ShouldSerializeStav() { return IsPropertyChanged(nameof(Stav)); }

        [JsonProperty(PropertyName = "stavUhrazenosti")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string StavUhrazenosti { get => _StavUhrazenosti; set => Set(ref _StavUhrazenosti, value); }
        private string _StavUhrazenosti;
        public bool ShouldSerializeStavUhrazenosti() { return IsPropertyChanged(nameof(StavUhrazenosti)); }

        [JsonProperty(PropertyName = "variabilniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string VariabilniSymbol { get => _VariabilniSymbol; set => Set(ref _VariabilniSymbol, value); }
        private string _VariabilniSymbol;
        public bool ShouldSerializeVariabilniSymbol() { return IsPropertyChanged(nameof(VariabilniSymbol)); }

        [JsonProperty(PropertyName = "cisloJednaci")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string CisloJednaci { get => _CisloJednaci; set => Set(ref _CisloJednaci, value); }
        private string _CisloJednaci;
        public bool ShouldSerializeCisloJednaci() { return IsPropertyChanged(nameof(CisloJednaci)); }

        [JsonIgnore]
        [JsonProperty(PropertyName = "recordNumber")]
        public int? RecordNumber { get => _RecordNumber; set => Set(ref _RecordNumber, value); }
        private int? _RecordNumber;
        public bool ShouldSerializeRecordNumber() { return IsPropertyChanged(nameof(RecordNumber)); }
        [JsonProperty(PropertyName = "cenaCelkem")]
        public decimal? CenaCelkem { get => _CenaCelkem; set => Set(ref _CenaCelkem, value); }
        private decimal? _CenaCelkem;
        public bool ShouldSerializeCenaCelkem() { return IsPropertyChanged(nameof(CenaCelkem)); }

        [JsonIgnore]
        [JsonProperty(PropertyName = "cisloPoradace")]
        public int? CisloPoradace { get => _CisloPoradace; set => Set(ref _CisloPoradace, value); }
        private int? _CisloPoradace;
        public bool ShouldSerializeCisloPoradace() { return IsPropertyChanged(nameof(CisloPoradace)); }
        [JsonProperty(PropertyName = "datumDuzp")]
        public DateTime? DatumDuzp { get => _DatumDuzp; set => Set(ref _DatumDuzp, value); }
        private DateTime? _DatumDuzp;
        public bool ShouldSerializeDatumDuzp() { return IsPropertyChanged(nameof(DatumDuzp)); }
        [JsonProperty(PropertyName = "datumPorizeni")]
        public DateTime? DatumPorizeni { get => _DatumPorizeni; set => Set(ref _DatumPorizeni, value); }
        private DateTime? _DatumPorizeni;
        public bool ShouldSerializeDatumPorizeni() { return IsPropertyChanged(nameof(DatumPorizeni)); }
        [JsonProperty(PropertyName = "datumSplatnosti")]
        public DateTime? DatumSplatnosti { get => _DatumSplatnosti; set => Set(ref _DatumSplatnosti, value); }
        private DateTime? _DatumSplatnosti;
        public bool ShouldSerializeDatumSplatnosti() { return IsPropertyChanged(nameof(DatumSplatnosti)); }
        [JsonProperty(PropertyName = "konstantniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string KonstantniSymbol { get => _KonstantniSymbol; set => Set(ref _KonstantniSymbol, value); }
        private string _KonstantniSymbol;
        public bool ShouldSerializeKonstantniSymbol() { return IsPropertyChanged(nameof(KonstantniSymbol)); }

        [JsonProperty(PropertyName = "organizaceOdberatel")]
        public OrganizaceGetResponseElement OrganizaceOdberatel { get => _OrganizaceOdberatel; set => Set(ref _OrganizaceOdberatel, value); }
        private OrganizaceGetResponseElement _OrganizaceOdberatel;
        public bool ShouldSerializeOrganizaceOdberatel() { return IsPropertyChanged(nameof(OrganizaceOdberatel)); }
        [JsonProperty(PropertyName = "organizacePrijemce")]
        public OrganizaceGetResponseElement OrganizacePrijemce { get => _OrganizacePrijemce; set => Set(ref _OrganizacePrijemce, value); }
        private OrganizaceGetResponseElement _OrganizacePrijemce;
        public bool ShouldSerializeOrganizacePrijemce() { return IsPropertyChanged(nameof(OrganizacePrijemce)); }
        [JsonProperty(PropertyName = "poznamka")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Poznamka { get => _Poznamka; set => Set(ref _Poznamka, value); }
        private string _Poznamka;
        public bool ShouldSerializePoznamka() { return IsPropertyChanged(nameof(Poznamka)); }
        [JsonProperty(PropertyName = "specifickySymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string SpecifickySymbol { get => _SpecifickySymbol; set => Set(ref _SpecifickySymbol, value); }
        private string _SpecifickySymbol;
        public bool ShouldSerializeSpecifickySymbol() { return IsPropertyChanged(nameof(SpecifickySymbol)); }

        [JsonIgnore]
        [JsonProperty(PropertyName = "typUhrady")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string TypUhrady { get => _TypUhrady; set => Set(ref _TypUhrady, value); }
        private string _TypUhrady;
        public bool ShouldSerializeTypUhrady() { return IsPropertyChanged(nameof(TypUhrady)); }
        [JsonProperty(PropertyName = "kontaceHlavicka")]
        public PvdAllocationGetResponseElement KontaceHlavicka { get => _KontaceHlavicka; set => Set(ref _KontaceHlavicka, value); }
        private PvdAllocationGetResponseElement _KontaceHlavicka;
        public bool ShouldSerializeKontaceHlavicka() { return IsPropertyChanged(nameof(KontaceHlavicka)); }

        [JsonProperty(PropertyName = "polozky")]
        public List<Polozka> Polozky { get => _Polozky; set => Set(ref _Polozky, value); }
        private List<Polozka> _Polozky;
        public bool ShouldSerializePolozky() { return IsPropertyChanged(nameof(Polozky)); }
        [JsonProperty(PropertyName = "zbyvaUhradit")]
        public decimal? ZbyvaUhradit { get => _ZbyvaUhradit; set => Set(ref _ZbyvaUhradit, value); }
        private decimal? _ZbyvaUhradit;
        public bool ShouldSerializeZbyvaUhradit() { return IsPropertyChanged(nameof(ZbyvaUhradit)); }
        [JsonIgnore]
        [JsonProperty(PropertyName = "cisloBanSpojVlastniPp")]
        public int? CisloBanSpojVlastniPp { get => _CisloBanSpojVlastniPp; set => Set(ref _CisloBanSpojVlastniPp, value); }
        private int? _CisloBanSpojVlastniPp;
        public bool ShouldSerializeCisloBanSpojVlastniPp() { return IsPropertyChanged(nameof(CisloBanSpojVlastniPp)); }
        [JsonIgnore]
        [JsonProperty(PropertyName = "parovaciSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string ParovaciSymbol { get => _ParovaciSymbol; set => Set(ref _ParovaciSymbol, value); }
        private string _ParovaciSymbol;
        public bool ShouldSerializeParovaciSymbol() { return IsPropertyChanged(nameof(ParovaciSymbol)); }

    }

    public class InvoicesIssuedPostPutRequest : BaseItem
    {
        [JsonProperty(PropertyName = "cisloJednaci")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string CisloJednaci { get => _CisloJednaci; set => Set(ref _CisloJednaci, value); }
        private string _CisloJednaci;
        public bool ShouldSerializeCisloJednaci() { return IsPropertyChanged(nameof(CisloJednaci)); }

        [JsonProperty(PropertyName = "cisloPoradace")]
        public int CisloPoradace { get => _CisloPoradace; set => Set(ref _CisloPoradace, value); }
        private int _CisloPoradace;
        public bool ShouldSerializeCisloPoradace() { return IsPropertyChanged(nameof(CisloPoradace)); }

        [JsonProperty(PropertyName = "datumDuzp")]
        public DateTime? DatumDuzp { get => _DatumDuzp; set => Set(ref _DatumDuzp, value); }
        private DateTime? _DatumDuzp;
        public bool ShouldSerializeDatumDuzp() { return IsPropertyChanged(nameof(DatumDuzp)); }

        [JsonProperty(PropertyName = "datumPorizeni")]
        public DateTime DatumPorizeni { get => _DatumPorizeni; set => Set(ref _DatumPorizeni, value); }
        private DateTime _DatumPorizeni;
        public bool ShouldSerializeDatumPorizeni() { return IsPropertyChanged(nameof(DatumPorizeni)); }

        [JsonProperty(PropertyName = "datumSplatnosti")]
        public DateTime? DatumSplatnosti { get => _DatumSplatnosti; set => Set(ref _DatumSplatnosti, value); }
        private DateTime? _DatumSplatnosti;
        public bool ShouldSerializeDatumSplatnosti() { return IsPropertyChanged(nameof(DatumSplatnosti)); }

        [JsonRequired]
        [JsonProperty(PropertyName = "fakturaIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string FakturaIdEx { get => _FakturaIdEx; set => Set(ref _FakturaIdEx, value); }
        private string _FakturaIdEx;
        public bool ShouldSerializeFakturaIdEx() { return IsPropertyChanged(nameof(FakturaIdEx)); }

        [JsonProperty(PropertyName = "konstantniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string KonstantniSymbol { get => _KonstantniSymbol; set => Set(ref _KonstantniSymbol, value); }
        private string _KonstantniSymbol;
        public bool ShouldSerializeKonstantniSymbol() { return IsPropertyChanged(nameof(KonstantniSymbol)); }
      
        [JsonRequired]
        [JsonProperty(PropertyName = "organizace")]
        public OrganizacePostPutRequest Organizace { get => _Organizace; set => Set(ref _Organizace, value); }
        private OrganizacePostPutRequest _Organizace;
        public bool ShouldSerializeOrganizace() { return IsPropertyChanged(nameof(Organizace)); }

        [JsonProperty(PropertyName = "organizace2")]
        public OrganizacePostPutRequest Organizace2 { get => _Organizace2; set => Set(ref _Organizace2, value); }
        private OrganizacePostPutRequest _Organizace2;
        public bool ShouldSerializeOrganizace2() { return IsPropertyChanged(nameof(Organizace2)); }

        [JsonProperty(PropertyName = "poznamka")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Poznamka { get => _Poznamka; set => Set(ref _Poznamka, value); }
        private string _Poznamka;
        public bool ShouldSerializePoznamka() { return IsPropertyChanged(nameof(Poznamka)); }

        [JsonProperty(PropertyName = "specifickySymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string SpecifickySymbol { get => _SpecifickySymbol; set => Set(ref _SpecifickySymbol, value); }
        private string _SpecifickySymbol;
        public bool ShouldSerializeSpecifickySymbol() { return IsPropertyChanged(nameof(SpecifickySymbol)); }

        [JsonProperty(PropertyName = "typUhrady")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string TypUhrady { get => _TypUhrady; set => Set(ref _TypUhrady, value); }
        private string _TypUhrady;
        public bool ShouldSerializeTypUhrady() { return IsPropertyChanged(nameof(TypUhrady)); }

        [JsonRequired]
        [JsonProperty(PropertyName = "variabilniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string VariabilniSymbol { get => _VariabilniSymbol; set => Set(ref _VariabilniSymbol, value); }
        private string _VariabilniSymbol;
        public bool ShouldSerializeVariabilniSymbol() { return IsPropertyChanged(nameof(VariabilniSymbol)); }

        [JsonProperty(PropertyName = "kontaceId")]
        public int KontaceId { get => _KontaceId; set => Set(ref _KontaceId, value); }
        private int _KontaceId;
        public bool ShouldSerializeKontaceId() { return IsPropertyChanged(nameof(KontaceId)); }

        [JsonProperty(PropertyName = "polozky")]
        public List<Polozka> Polozky { get => _Polozky; set => Set(ref _Polozky, value); }
        private List<Polozka> _Polozky;
        public bool ShouldSerializePolozky() { return IsPropertyChanged(nameof(Polozky)); }
    }

    public class InvoicesIssuedPostPutResponse : InvoicesIssuedGetResponseElement
    {
        /// <summary>
        /// CZ: Chybové hlášky
        /// </summary>
        [JsonProperty(PropertyName = "errors")]
        public List<string> errors;
    }
}
