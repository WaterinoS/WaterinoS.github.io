﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Newtonsoft.Json;
using Noris.LCS.WebApi.Globals.Contracts;

namespace Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts
{
    public class EvidenceTypeHeaderBase : BaseItem
    {
        [JsonIgnore]
        [JsonProperty(PropertyName = "cisloSubjektu")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.cislo_subjektu")]
        public int? Id { get => _Id; set => Set(ref _Id, value); }
        private int? _Id;

        [JsonProperty(PropertyName = "kod")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.reference_subjektu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string Reference { get => _Reference; set => Set(ref _Reference, value); }
        private string _Reference;
        public bool ShouldSerializeReference() { return IsPropertyChanged(nameof(Reference)); }

        [JsonProperty(PropertyName = "nazev")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.nazev_subjektu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string Nazev { get => _Nazev; set => Set(ref _Nazev, value); }
        private string _Nazev;
        public bool ShouldSerializeNazev() { return IsPropertyChanged(nameof(Nazev)); }

        [JsonIgnore]
        [JsonProperty(PropertyName = "cisloPoradace")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.cislo_poradace")]
        public int? CisloPoradace { get => _CisloPoradace; set => Set(ref _CisloPoradace, value); }
        private int? _CisloPoradace;
        public bool ShouldSerializeCisloPoradace() { return IsPropertyChanged(nameof(CisloPoradace)); }

        [JsonIgnore]
        [JsonProperty(PropertyName = "externiId")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.externi_id")]
        public int? ExterniId { get => _ExterniId; set => Set(ref _ExterniId, value); }
        private int? _ExterniId;
        public bool ShouldSerializeExterniId() { return IsPropertyChanged(nameof(ExterniId)); }

        [JsonProperty(PropertyName = "jeMistniPoplatek")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.je_mistni_poplatek")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string JeMistniPoplatek { get => _JeMistniPoplatek; set => Set(ref _JeMistniPoplatek, value); }
        private string _JeMistniPoplatek;
        public bool ShouldSerializeJeMistniPoplatek() { return IsPropertyChanged(nameof(JeMistniPoplatek)); }

        [JsonProperty(PropertyName = "jePrijemDleDanovehoRadu")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.je_prijem_dle_danoveho_radu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string JePrijemDleDanovehoRadu { get => _JePrijemDleDanovehoRadu; set => Set(ref _JePrijemDleDanovehoRadu, value); }
        private string _JePrijemDleDanovehoRadu;
        public bool ShouldSerializeJePrijemDleDanovehoRadu() { return IsPropertyChanged(nameof(JePrijemDleDanovehoRadu)); }

        [JsonProperty(PropertyName = "jeUctovatelny")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.je_uctovatelny")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string JeUctovatelny { get => _JeUctovatelny; set => Set(ref _JeUctovatelny, value); }
        private string _JeUctovatelny;
        public bool ShouldSerializeJeUctovatelny() { return IsPropertyChanged(nameof(JeUctovatelny)); }

        [JsonProperty(PropertyName = "legislativa")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.legislativa")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string Legislativa { get => _Legislativa; set => Set(ref _Legislativa, value); }
        private string _Legislativa;
        public bool ShouldSerializeLegislativa() { return IsPropertyChanged(nameof(Legislativa)); }

        [JsonProperty(PropertyName = "platnostOd")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.platnost_od")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string PlatnostOd { get => _PlatnostOd; set => Set(ref _PlatnostOd, value); }
        private string _PlatnostOd;
        public bool ShouldSerializePlatnostOd() { return IsPropertyChanged(nameof(PlatnostOd)); }

        [JsonProperty(PropertyName = "platnostDo")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.platnost_do")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string PlatnostDo { get => _PlatnostDo; set => Set(ref _PlatnostDo, value); }
        private string _PlatnostDo;
        public bool ShouldSerializePlatnostDo() { return IsPropertyChanged(nameof(PlatnostDo)); }

        [JsonProperty(PropertyName = "pouzeProEvidencniAgendu")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.pouze_pro_evidencni_agendu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string PouzeProEvidencniAgendu { get => _PouzeProEvidencniAgendu; set => Set(ref _PouzeProEvidencniAgendu, value); }
        private string _PouzeProEvidencniAgendu;
        public bool ShouldSerializePouzeProEvidencniAgendu() { return IsPropertyChanged(nameof(PouzeProEvidencniAgendu)); }

        [JsonProperty(PropertyName = "pouzivaKalendarPredpisu")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.pouziva_kalendar_predpisu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string PouzivaKalendarPredpisu { get => _PouzivaKalendarPredpisu; set => Set(ref _PouzivaKalendarPredpisu, value); }
        private string _PouzivaKalendarPredpisu;
        public bool ShouldSerializePouzivaKalendarPredpisu() { return IsPropertyChanged(nameof(PouzivaKalendarPredpisu)); }

        [JsonProperty(PropertyName = "pouzivaKartuPrijmu")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.pouziva_kartu_prijmu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string PouzivaKartuPrijmu { get => _PouzivaKartuPrijmu; set => Set(ref _PouzivaKartuPrijmu, value); }
        private string _PouzivaKartuPrijmu;
        public bool ShouldSerializePouzivaKartuPrijmu() { return IsPropertyChanged(nameof(PouzivaKartuPrijmu)); }

        [JsonProperty(PropertyName = "pouzivaOpravnePolozky")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.pouziva_opravne_polozky")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string PouzivaOpravnePolozky { get => _PouzivaOpravnePolozky; set => Set(ref _PouzivaOpravnePolozky, value); }
        private string _PouzivaOpravnePolozky;
        public bool ShouldSerializePouzivaOpravnePolozky() { return IsPropertyChanged(nameof(PouzivaOpravnePolozky)); }

        [JsonProperty(PropertyName = "pouzivaPodrozvahu")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.pouziva_podrozvahu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string PouzivaPodrozvahu { get => _PouzivaPodrozvahu; set => Set(ref _PouzivaPodrozvahu, value); }
        private string _PouzivaPodrozvahu;
        public bool ShouldSerializePouzivaPodrozvahu() { return IsPropertyChanged(nameof(PouzivaPodrozvahu)); }

        [JsonProperty(PropertyName = "pouzivaStorno")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.pouziva_storno")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string PouzivaStorno { get => _PouzivaStorno; set => Set(ref _PouzivaStorno, value); }
        private string _PouzivaStorno;
        public bool ShouldSerializePouzivaStorno() { return IsPropertyChanged(nameof(PouzivaStorno)); }

        [JsonIgnore]
        [JsonProperty(PropertyName = "typ")]
        [AbsoluteDbName("lcs.PreEvidencniTyp.typ")]
        public int? Typ { get => _Typ; set => Set(ref _Typ, value); }
        private int? _Typ;
        public bool ShouldSerializeTyp() { return IsPropertyChanged(nameof(Typ)); }
    }


    public class EvidenceTypeHeaderGetBase : EvidenceTypeHeaderBase
    {

    }

    /// <summary>
    /// API GET Customer/Pantheon/CiselnikEvidencniTyp QUERY parameters
    /// </summary>
    public class EvidenceTypeGetRequest : EvidenceTypeHeaderGetBase
    {
       
    }

    /// <summary>
    /// API GET Customer/Pantheon/CiselnikEvidencniTyp RESPONSE
    /// API GET Customer/Pantheon/CiselnikEvidencniTyp/{id} RESPONSE
    /// </summary>
    public class EvidenceTypeGetResponse
    {
        /// <summary>
        /// CZ: Kolekce organizací.
        /// </summary>
        public List<EvidenceTypeGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class EvidenceTypeGetResponseElement : EvidenceTypeHeaderBase
    {
    }
}
