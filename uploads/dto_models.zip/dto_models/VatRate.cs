﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Noris.LCS.WebApi.Globals.Contracts;

namespace Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts
{
    public class VatRateHeaderBase : BaseItem
    {
        [JsonProperty(PropertyName = "kod")]
        [AbsoluteDbName("lcs.sazba_dane.reference_subjektu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Reference { get => _Reference; set => Set(ref _Reference, value); }
        private string _Reference;
        public bool ShouldSerializeReference() { return IsPropertyChanged(nameof(Reference)); }

        // generate code for property sazba type decimal
        [JsonProperty(PropertyName = "sazba")]
        [AbsoluteDbName("lcs.sazba_dane.sazba")]
        public decimal? Sazba { get => _Sazba; set => Set(ref _Sazba, value); }
        private decimal? _Sazba;
        public bool ShouldSerializeSazba() { return IsPropertyChanged(nameof(Sazba)); }

        [JsonProperty(PropertyName = "popis")]
        [AbsoluteDbName("lcs.sazba_dane.nazev_subjektu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Popis { get => _Popis; set => Set(ref _Popis, value); }
        private string _Popis;
        public bool ShouldSerializePopis() { return IsPropertyChanged(nameof(Popis)); }

        [JsonProperty(PropertyName = "platnostOd")]
        [AbsoluteDbName("lcs.sazba_dane.platnost_od")]
        public DateTime? PlatnostOd { get => _PlatnostOd; set => Set(ref _PlatnostOd, value); }
        private DateTime? _PlatnostOd;
        public bool ShouldSerializePlatnostOd() { return IsPropertyChanged(nameof(PlatnostOd)); }
    }

    /// <summary>
    /// API GET Customer/Pantheon/CiselnikKodDph/{platnostOd} RESPONSE
    /// </summary>
    public class VatRateGetResponse
    {
        /// <summary>
        /// CZ: Kolekce sazeb dph.
        /// </summary>
        public List<VatRateGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class VatRateGetResponseElement : VatRateHeaderBase
    {
    }

    internal class VatRate
    {
    }
}
