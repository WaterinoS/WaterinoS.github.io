﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Noris.LCS.WebApi.Globals.Contracts;

namespace Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts
{
    /// <summary>
    /// API GET Customer/Pantheon/Kniha QUERY parameters
    /// </summary>
    public class ReceivablesLedgerGetRequest : KnihaSearch
    {

    }

    /// <summary>
    /// API GET Customer/Pantheon/Kniha RESPONSE
    /// </summary>
    public class ReceivablesLedgerGetResponse
    {
        /// <summary>
        /// CZ: Kolekce organizací.
        /// </summary>
        public List<ReceivablesLedgerGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class ReceivablesLedgerGetResponseElement : BaseItem
    {
        /// <summary>
        /// CZ: Název knihy
        /// </summary>
        [JsonProperty(PropertyName = "nazev")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Nazev { get => _Nazev; set => Set(ref _Nazev, value); }
        private string _Nazev;
        public bool ShouldSerializeNazev() { return IsPropertyChanged(nameof(Nazev)); }

        /// <summary>
        /// CZ: Kód knihy
        /// </summary>
        [JsonProperty(PropertyName = "kod")]
        public int ? Kod { get => _Kod; set => Set(ref _Kod, value); }
        private int ? _Kod;
        public bool ShouldSerializeKod() { return IsPropertyChanged(nameof(Kod)); }

        /// <summary>
        /// CZ: Identifikátor knihy
        /// </summary>
        [JsonProperty(PropertyName = "knihaId")]
        public int ? KnihaId { get => _KnihaId; set => Set(ref _KnihaId, value); }
        private int ? _KnihaId;
        public bool ShouldSerializeKnihaId() { return IsPropertyChanged(nameof(KnihaId)); }

        /// <summary>
        /// CZ: Datum platnosti od
        /// </summary>
        /// <example>2001-02-29</example>
        [JsonProperty(PropertyName = "platnostOd")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PlatnostOd { get => _PlatnostOd; set => Set(ref _PlatnostOd, value); }
        private string _PlatnostOd;
        public bool ShouldSerializePlatnostOd() { return IsPropertyChanged(nameof(PlatnostOd)); }

        /// <summary>
        /// CZ: Datum platnosti do
        /// </summary>
        /// <example>2002-02-29</example>
        [JsonProperty(PropertyName = "platnostDo")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PlatnostDo { get => _PlatnostDo; set => Set(ref _PlatnostDo, value); }
        private string _PlatnostDo;
        public bool ShouldSerializePlatnostDo() { return IsPropertyChanged(nameof(PlatnostDo)); }

        /// <summary>
        /// CZ: Typ evidence (?)
        /// </summary>
        [JsonProperty(PropertyName = "evidTyp")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string EvidTyp { get => _EvidTyp; set => Set(ref _EvidTyp, value); }
        private string _EvidTyp;
        public bool ShouldSerializeEvidTyp() { return IsPropertyChanged(nameof(EvidTyp)); }

        [JsonIgnore]
        public int VychoziZpusobPlatby;

        [JsonIgnore]
        public int AktivniRok;

        [JsonIgnore]
        public int? PoradacPreplatku;
    }

    /// <summary>
    /// CZ: Třída hodnot pro získání/vyhledávání Knih poplatků
    ///     (filtrování je typu AND)
    /// </summary>
    public class KnihaSearch : BaseItem
    {
        /// <summary>
        /// CZ: Evidenční typ (pole)
        /// </summary>
        /// <example>MKO,MPO</example>
        [JsonProperty(PropertyName = "evidencniTyp")]
        public List<string> EvidencniTyp { get => _EvidencniTyp; set => Set(ref _EvidencniTyp, value); }
        private List<string> _EvidencniTyp;
        public bool ShouldSerializeEvidencniTyp() { return IsPropertyChanged(nameof(EvidencniTyp)); }
    }
}
