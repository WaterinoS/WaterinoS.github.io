﻿using System;
using Newtonsoft.Json;
using System.Collections.Generic;
using Noris.LCS.WebApi.Globals.Contracts;

namespace Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts
{
    #region Predpis
    /// <summary>
    /// API GET Customer/Pantheon/Predpis QUERY parameters
    /// </summary>
    public class PayerprescriptionGetRequest : BaseItem
    {
        /// <summary>
        /// CZ: Kód knihy
        /// </summary>
        [JsonProperty(PropertyName = "kodKnihy")]
        public int? KodKnihy { get; set; }
        /// <summary>
        /// CZ: ID dokladu
        /// </summary>
        [JsonProperty(PropertyName = "predpisId")]
        public int? PredpisId { get; set; }
        /// <summary>
        /// CZ: ID dokladu externí
        /// </summary>
        [JsonProperty(PropertyName = "predpisIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PredpisIdEx { get; set; }
        /// <summary>
        /// CZ: ID plátce
        /// </summary>
        [JsonProperty(PropertyName = "platceId")]
        public int? PlatceId { get; set; }
        /// <summary>
        /// CZ: ID plátce externí
        /// </summary>
        [JsonProperty(PropertyName = "platceIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PlatceIdEx { get; set; }
        /// <summary>
        /// CZ: Variabilní symbol
        /// </summary>
        [JsonProperty(PropertyName = "variabilniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string VariabilniSymbol { get; set; }
        /// <summary>
        /// CZ: Parovací symbol
        /// </summary>
        [JsonProperty(PropertyName = "parovaciSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string ParovaciSymbol { get; set; }
    }

    /// <summary>
    /// API GET Customer/Pantheon/Predpis RESPONSE
    /// </summary>
    public class PayerprescriptionGetResponse
    {
        /// <summary>
        /// CZ: Kolekce organizací.
        /// </summary>
        public List<PayerprescriptionGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class PayerprescriptionGetResponseElement : BaseItem
    {
        [JsonProperty(PropertyName = "predpisId")]
        public int? PredpisId { get; set; }

        [JsonProperty(PropertyName = "predpisIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PredpisIdEx { get; set; }

        [JsonProperty(PropertyName = "platceId")]
        public int? PlatceId { get; set; }
        [JsonConverter(typeof(NullToEmptyStringConverter))]

        [JsonProperty(PropertyName = "platceIdEx")]
        public string PlatceIdEx { get; set; }

        [JsonProperty(PropertyName = "faktura")]
        public InvoicesIssuedGetResponseElement Faktura { get; set; }

        [JsonProperty(PropertyName = "cisloUctu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string CisloUctu { get; set; }

        [JsonProperty(PropertyName = "kodBanky")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string KodBanky { get; set; }
    }

    /// <summary>
    /// API POST|PUT Customer/Pantheon/Predpis REQUEST
    /// </summary>
    public class PayerprescriptionPostPutRequest : BaseItem
    {
        /// <summary>
        /// CZ: Datum splatnosti
        /// </summary>
        [JsonProperty(PropertyName = "datumSplatnosti")]
        public DateTime? DatumSplatnosti { get; set; }
        /// <summary>
        /// CZ: ID dokladu externí
        /// </summary>
        [JsonProperty(PropertyName = "predpisIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PredpisIdEx { get; set; }
        /// <summary>
        /// CZ: ID plátce
        /// </summary>
        [JsonRequired]
        [JsonProperty(PropertyName = "platceId")]
        public int? PlatceId { get; set; }
        /// <summary>
        /// CZ: ID plátce externí
        /// </summary>
        [JsonRequired]
        [JsonProperty(PropertyName = "platceIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PlatceIdEx { get; set; }


        [JsonRequired]
        [JsonProperty(PropertyName = "faktura")]
        public InvoicesIssuedPostPutRequest Faktura { get; set; }

        [JsonIgnore]
        public int idKartaPoplatnika;
        [JsonIgnore]
        public PayerGetResponseElement platceProPredpis;
        [JsonIgnore]
        public InvoicesIssuedGetResponseElement fakturaProPredpis;
        [JsonIgnore]
        public ReceivablesLedgerGetResponseElement knihaPredpisu;
    }

    /// <summary>
    /// API POST|PUT Customer/Pantheon/Predpis RESPONSE
    /// </summary>
    public class PayerprescriptionPostPutResponse : PayerprescriptionGetResponseElement
    {
        /// <summary>
        /// CZ: Chybové hlášky
        /// </summary>
        [JsonProperty(PropertyName = "errors")]
        public List<string> errors;
    }

    public class PayerprescriptionInvalidateGetRequest
    {
        /// <summary>
        /// CZ: Datum ukončení
        /// </summary>
        /// <example>2021-12-31</example>
        [JsonProperty(PropertyName = "DatumUkonceni")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string DatumUkonceni { get; set; }
    }
    #endregion Predpis

    #region Preplatek
    /// <summary>
    /// API GET Customer/Pantheon/Preplatek QUERY parameters
    /// </summary>
    public class OverpaymentGetRequest : BaseItem
    {
        /// <summary>
        /// CZ: Kód knihy
        /// </summary>
        [JsonProperty(PropertyName = "kodKnihy")]
        public int? KodKnihy { get; set; }
        /// <summary>
        /// CZ: ID dokladu
        /// </summary>
        [JsonProperty(PropertyName = "preplatekId")]
        public int? PreplatekId { get; set; }
        /// <summary>
        /// CZ: ID dokladu externí
        /// </summary>
        [JsonProperty(PropertyName = "preplatekIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PreplatekIdEx { get; set; }
        /// <summary>
        /// CZ: ID plátce
        /// </summary>
        [JsonProperty(PropertyName = "platceId")]
        public int? PlatceId { get; set; }
        /// <summary>
        /// CZ: ID plátce externí
        /// </summary>
        [JsonProperty(PropertyName = "platceIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PlatceIdEx { get; set; }
        /// <summary>
        /// CZ: Variabilní symbol
        /// </summary>
        [JsonProperty(PropertyName = "variabilniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string VariabilniSymbol { get; set; }
        /// <summary>
        /// CZ: Parovací symbol
        /// </summary>
        [JsonProperty(PropertyName = "parovaciSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string ParovaciSymbol { get; set; }
    }

    /// <summary>
    /// API GET Customer/Pantheon/Preplatek RESPONSE
    /// </summary>
    public class OverpaymentGetResponse
    {
        /// <summary>
        /// CZ: Kolekce organizací.
        /// </summary>
        public List<OverpaymentGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class OverpaymentGetResponseElement : BaseItem
    {
        [JsonProperty(PropertyName = "preplatekId")]
        public int? PreplatekId { get; set; }

        [JsonProperty(PropertyName = "preplatekIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PreplatekIdEx { get; set; }

        [JsonProperty(PropertyName = "platceId")]
        public int? PlatceId { get; set; }
        [JsonConverter(typeof(NullToEmptyStringConverter))]

        [JsonProperty(PropertyName = "platceIdEx")]
        public string PlatceIdEx { get; set; }

        [JsonProperty(PropertyName = "dobropis")]
        public CreditNoteGetResponseElement Dobropis { get; set; }
    }

    /// <summary>
    /// API POST|PUT Customer/Pantheon/Preplatek REQUEST
    /// </summary>
    public class OverpaymentPostPutRequest : BaseItem
    {
        /// <summary>
        /// CZ: Datum splatnosti
        /// </summary>
        [JsonProperty(PropertyName = "datumSplatnosti")]
        public DateTime? DatumSplatnosti { get; set; }
        /// <summary>
        /// CZ: ID dokladu externí
        /// </summary>
        [JsonProperty(PropertyName = "preplatekIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PreplatekIdEx { get; set; }
        /// <summary>
        /// CZ: ID plátce
        /// </summary>
        [JsonRequired]
        [JsonProperty(PropertyName = "platceId")]
        public int? PlatceId { get; set; }
        /// <summary>
        /// CZ: ID plátce externí
        /// </summary>
        [JsonRequired]
        [JsonProperty(PropertyName = "platceIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PlatceIdEx { get; set; }

        [JsonRequired]
        [JsonProperty(PropertyName = "dobropis")]
        public CreditNotePostPutRequest Dobropis { get; set; }

        [JsonIgnore]
        public PayerGetResponseElement platceProPredpis;
        [JsonIgnore]
        public CreditNoteGetResponseElement dobropisProPredpis;
        [JsonIgnore]
        public ReceivablesLedgerGetResponseElement knihaPredpisu;
    }

    /// <summary>
    /// API POST|PUT Customer/Pantheon/Preplatek RESPONSE
    /// </summary>
    public class OverpaymentPostPutResponse : OverpaymentGetResponseElement
    {
        /// <summary>
        /// CZ: Chybové hlášky
        /// </summary>
        [JsonProperty(PropertyName = "errors")]
        public List<string> errors;
    }
    #endregion Preplatek
}
