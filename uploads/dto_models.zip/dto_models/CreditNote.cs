﻿using System;
using System.Collections.Generic;
using System.Text;

using Newtonsoft.Json;
using Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts;
using Noris.LCS.WebApi.Globals.Contracts;

namespace Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts
{
    public class CreditNoteHeaderBase : BaseItem
    {
        [JsonIgnore]
        [JsonProperty(PropertyName = "recordNumber")]
        public int? RecordNumber { get => _RecordNumber; set => Set(ref _RecordNumber, value); }
        private int? _RecordNumber;
        public bool ShouldSerializeRecordNumber() { return IsPropertyChanged(nameof(RecordNumber)); }
       
        [JsonProperty(PropertyName = "cisloJednaci")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string CisloJednaci { get => _CisloJednaci; set => Set(ref _CisloJednaci, value); }
        private string _CisloJednaci;
        public bool ShouldSerializeCisloJednaci() { return IsPropertyChanged(nameof(CisloJednaci)); }

        [JsonIgnore]
        [JsonProperty(PropertyName = "cisloPoradace")]
        public int? CisloPoradace { get => _CisloPoradace; set => Set(ref _CisloPoradace, value); }
        private int? _CisloPoradace;
        public bool ShouldSerializeCisloPoradace() { return IsPropertyChanged(nameof(CisloPoradace)); }
        
        [JsonProperty(PropertyName = "datumDuzp")]
        public string DatumDuzp { get => _DatumDuzp; set => Set(ref _DatumDuzp, value); }
        private string _DatumDuzp;
        public bool ShouldSerializeDatumDuzp() { return IsPropertyChanged(nameof(DatumDuzp)); }
       
        [JsonProperty(PropertyName = "datumPorizeni")]
        public string DatumPorizeni { get => _DatumPorizeni; set => Set(ref _DatumPorizeni, value); }
        private string _DatumPorizeni;
        public bool ShouldSerializeDatumPorizeni() { return IsPropertyChanged(nameof(DatumPorizeni)); }
        
        [JsonProperty(PropertyName = "datumSplatnosti")]
        public string DatumSplatnosti { get => _DatumSplatnosti; set => Set(ref _DatumSplatnosti, value); }
        private string _DatumSplatnosti;
        public bool ShouldSerializeDatumSplatnosti() { return IsPropertyChanged(nameof(DatumSplatnosti)); }

        [JsonProperty(PropertyName = "dobropisId")]
        public int? DobropisId { get => _DobropisId; set => Set(ref _DobropisId, value); }
        private int? _DobropisId;
        public bool ShouldSerializeDobropisId() { return IsPropertyChanged(nameof(DobropisId)); }
        
        [JsonProperty(PropertyName = "dobropisIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string DobropisIdEx { get => _DobropisIdEx; set => Set(ref _DobropisIdEx, value); }
        private string _DobropisIdEx;
        public bool ShouldSerializeDobropisIdEx() { return IsPropertyChanged(nameof(DobropisIdEx)); }
       
        [JsonProperty(PropertyName = "konstantniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string KonstantniSymbol { get => _KonstantniSymbol; set => Set(ref _KonstantniSymbol, value); }
        private string _KonstantniSymbol;
        public bool ShouldSerializeKonstantniSymbol() { return IsPropertyChanged(nameof(KonstantniSymbol)); }
        
        [JsonProperty(PropertyName = "organizaceOdberatel")]
        public OrganizaceGetResponseElement OrganizaceOdberatel { get => _OrganizaceOdberatel; set => Set(ref _OrganizaceOdberatel, value); }
        private OrganizaceGetResponseElement _OrganizaceOdberatel;
        public bool ShouldSerializeOrganizaceOdberatel() { return IsPropertyChanged(nameof(OrganizaceOdberatel)); }
        
        [JsonProperty(PropertyName = "organizacePrijemce")]
        public OrganizaceGetResponseElement OrganizacePrijemce { get => _OrganizacePrijemce; set => Set(ref _OrganizacePrijemce, value); }
        private OrganizaceGetResponseElement _OrganizacePrijemce;
        public bool ShouldSerializeOrganizacePrijemce() { return IsPropertyChanged(nameof(OrganizacePrijemce)); }
      
        [JsonProperty(PropertyName = "poznamka")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Poznamka { get => _Poznamka; set => Set(ref _Poznamka, value); }
        private string _Poznamka;
        public bool ShouldSerializePoznamka() { return IsPropertyChanged(nameof(Poznamka)); }
       
        [JsonProperty(PropertyName = "specifickySymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string SpecifickySymbol { get => _SpecifickySymbol; set => Set(ref _SpecifickySymbol, value); }
        private string _SpecifickySymbol;
        public bool ShouldSerializeSpecifickySymbol() { return IsPropertyChanged(nameof(SpecifickySymbol)); }
       
        [JsonProperty(PropertyName = "stav")]
        public int? Stav { get => _Stav; set => Set(ref _Stav, value); }
        private int? _Stav;
        public bool ShouldSerializeStav() { return IsPropertyChanged(nameof(Stav)); }
       
        [JsonProperty(PropertyName = "stavUhrazenosti")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string StavUhrazenosti { get => _StavUhrazenosti; set => Set(ref _StavUhrazenosti, value); }
        private string _StavUhrazenosti;
        public bool ShouldSerializeStavUhrazenosti() { return IsPropertyChanged(nameof(StavUhrazenosti)); }    

        [JsonProperty(PropertyName = "variabilniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string VariabilniSymbol { get => _VariabilniSymbol; set => Set(ref _VariabilniSymbol, value); }
        private string _VariabilniSymbol;
        public bool ShouldSerializeVariabilniSymbol() { return IsPropertyChanged(nameof(VariabilniSymbol)); }
       
        [JsonProperty(PropertyName = "zbyvaUhradit")]
        public decimal? ZbyvaUhradit { get => _ZbyvaUhradit; set => Set(ref _ZbyvaUhradit, value); }
        private decimal? _ZbyvaUhradit;
        public bool ShouldSerializeZbyvaUhradit() { return IsPropertyChanged(nameof(ZbyvaUhradit)); }
      
        [JsonProperty(PropertyName = "kontaceHlavicka")]
        public PvdAllocationGetResponseElement KontaceHlavicka { get => _KontaceHlavicka; set => Set(ref _KontaceHlavicka, value); }
        private PvdAllocationGetResponseElement _KontaceHlavicka;
        public bool ShouldSerializeKontaceHlavicka() { return IsPropertyChanged(nameof(KontaceHlavicka)); }
       
        [JsonProperty(PropertyName = "polozky")]
        public List<Polozka> Polozky { get => _Polozky; set => Set(ref _Polozky, value); }
        private List<Polozka> _Polozky;
        public bool ShouldSerializePolozky() { return IsPropertyChanged(nameof(Polozky)); }

        [JsonIgnore]
        [JsonProperty(PropertyName = "parovaciSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string ParovaciSymbol { get => _ParovaciSymbol; set => Set(ref _ParovaciSymbol, value); }
        private string _ParovaciSymbol;
        public bool ShouldSerializeParovaciSymbol() { return IsPropertyChanged(nameof(ParovaciSymbol)); }
    }

    public class Polozka : BaseItem
    {
        /// <summary>
        /// Atribut zveřejněn pouze pro čtení dat
        /// FakturaVydanaDto, DobropisDto
        /// </summary>
        [JsonProperty(PropertyName = "cena_celkem")]
        public decimal? CenaCelkem { get => _CenaCelkem; set => Set(ref _CenaCelkem, value); }
        private decimal? _CenaCelkem;
        public bool ShouldSerializeCenaCelkem() { return IsPropertyChanged(nameof(CenaCelkem)); }

        /// <summary>
        /// není třeba dopňovat
        /// platí, že
        /// pocet x cen_jedn = cena_zaklad
        /// </summary>
        [JsonProperty(PropertyName = "cena_jedn")]
        public decimal? CenaJedn { get => _CenaJedn; set => Set(ref _CenaJedn, value); }
        private decimal? _CenaJedn;
        public bool ShouldSerializeCenaJedn() { return IsPropertyChanged(nameof(CenaJedn)); }

        /// <summary>
        /// při doplnění této hodnoty se aplikačně doplní cena_jedn + pocet
        /// default
        /// pocet =1
        /// cena_jedn=cena_zaklad
        /// </summary>
        [JsonProperty(PropertyName = "cena_zaklad")]
        public decimal? CenaZaklad { get => _CenaZaklad; set => Set(ref _CenaZaklad, value); }
        private decimal? _CenaZaklad;
        public bool ShouldSerializeCenaZaklad() { return IsPropertyChanged(nameof(CenaZaklad)); }

        [JsonProperty(PropertyName = "dph_celkem")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string DphCelkem { get => _DphCelkem; set => Set(ref _DphCelkem, value); }
        private string _DphCelkem;
        public bool ShouldSerializeDphCelkem() { return IsPropertyChanged(nameof(DphCelkem)); }

        /// <summary>
        /// Kód DPH obsahuje referenci na třídu 48 Sazby DPH....kod repretentuje sazbu DPH
        /// </summary>
        [JsonProperty(PropertyName = "kod_dph")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string KodDph { get => _KodDph; set => Set(ref _KodDph, value); }
        private string _KodDph;
        public bool ShouldSerializeKodDph() { return IsPropertyChanged(nameof(KodDph)); }

        [JsonRequired]
        [JsonProperty(PropertyName = "nazev")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Nazev { get => _Nazev; set => Set(ref _Nazev, value); }
        private string _Nazev;
        public bool ShouldSerializeNazev() { return IsPropertyChanged(nameof(Nazev)); }

        /// <summary>
        /// vychozí hodnota = 1
        /// není třeba dopňovat
        /// platí, že
        /// pocet x cen_jedn = cena_zaklad
        /// </summary>
        [JsonProperty(PropertyName = "pocet")]
        public decimal? Pocet { get => _Pocet; set => Set(ref _Pocet, value); }
        private decimal? _Pocet;
        public bool ShouldSerializePocet() { return IsPropertyChanged(nameof(Pocet)); }

        /// <summary>
        /// Atribut zveřejněn pouze pro čtení dat
        /// FakturaVydanaDto, DobropisDto
        /// </summary>
        [JsonProperty(PropertyName = "sazba_dph")]
        public int? SazbaDph { get => _SazbaDph; set => Set(ref _SazbaDph, value); }
        private int? _SazbaDph;
        public bool ShouldSerializeSazbaDph() { return IsPropertyChanged(nameof(SazbaDph)); }
    }

    /// <summary>
    /// API GET Customer/Pantheon/Dobropis RESPONSE
    /// </summary>
    public class CreditNoteGetResponse
    {
        /// <summary>
        /// CZ: Kolekce dobropisů.
        /// </summary>
        public List<CreditNoteGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class CreditNoteGetResponseElement : CreditNoteHeaderBase
    {
    }

    public class CreditNoteGetRequest/*DobropisFvSearch; CreditNoteGetRequest*/ : BaseItem
    {
        /// <summary>
        /// Interní identifikátor Dobropisu
        /// </summary>
        /// <example>781254</example>
        [JsonProperty(PropertyName = "DobropisId")]
        public int? DobropisId { get => _DobropisId; set => Set(ref _DobropisId, value); }
        private int? _DobropisId;
        public bool ShouldSerializeDobropisId() { return IsPropertyChanged(nameof(DobropisId)); }


        /// <summary>
        /// Externí identifikátor Dobropisu
        /// </summary>
        /// <example>FVX_0001</example>
        [JsonProperty(PropertyName = "DobropisIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string DobropisIdEx { get => _DobropisIdEx; set => Set(ref _DobropisIdEx, value); }
        private string _DobropisIdEx;
        public bool ShouldSerializeDobropisIdEx() { return IsPropertyChanged(nameof(DobropisIdEx)); }

        /// <summary>
        /// údaje Organizace
        /// </summary>
        [JsonProperty(PropertyName = "Organizace")]
        public OrganizaceSearch Organizace { get => _Organizace; set => Set(ref _Organizace, value); }
        private OrganizaceSearch _Organizace;
        public bool ShouldSerializeOrganizace() { return IsPropertyChanged(nameof(Organizace)); }

        /// <summary>
        /// Stav
        /// </summary>
        /// <example>Stav</example>
        [JsonProperty(PropertyName = "Stav")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Stav { get => _Stav; set => Set(ref _Stav, value); }
        private string _Stav;
        public bool ShouldSerializeStav() { return IsPropertyChanged(nameof(Stav)); }

        /// <summary>
        /// Stav uhrazenosti
        /// </summary>
        /// <example>StavUhrazenosti</example>
        [JsonProperty(PropertyName = "StavUhrazenosti")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string StavUhrazenosti { get => _StavUhrazenosti; set => Set(ref _StavUhrazenosti, value); }
        private string _StavUhrazenosti;
        public bool ShouldSerializeStavUhrazenosti() { return IsPropertyChanged(nameof(StavUhrazenosti)); }

        /// <summary>
        /// Variabilní symbol
        /// </summary>
        /// <example>VarSymbol</example>
        [JsonProperty(PropertyName = "VariabilniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string VariabilniSymbol { get => _VariabilniSymbol; set => Set(ref _VariabilniSymbol, value); }
        private string _VariabilniSymbol;
        public bool ShouldSerializeVariabilniSymbol() { return IsPropertyChanged(nameof(VariabilniSymbol)); }

        /// <summary>
        /// Parovací symbol
        /// </summary>
        /// <example>ParovaciSymbol</example>
        [JsonProperty(PropertyName = "parovaciSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string ParovaciSymbol { get => _ParovaciSymbol; set => Set(ref _ParovaciSymbol, value); }
        private string _ParovaciSymbol;
        public bool ShouldSerializeParovaciSymbol() { return IsPropertyChanged(nameof(ParovaciSymbol)); }
    }

    public class CreditNotePostPutRequest : BaseItem
    {
        [JsonProperty(PropertyName = "cisloJednaci")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string CisloJednaci { get => _CisloJednaci; set => Set(ref _CisloJednaci, value); }
        private string _CisloJednaci;
        public bool ShouldSerializeCisloJednaci() { return IsPropertyChanged(nameof(CisloJednaci)); }

        [JsonRequired]
        [JsonProperty(PropertyName = "cisloPoradace")]
        public int? CisloPoradace { get => _CisloPoradace; set => Set(ref _CisloPoradace, value); }
        private int? _CisloPoradace;
        public bool ShouldSerializeCisloPoradace() { return IsPropertyChanged(nameof(CisloPoradace)); }

        [JsonProperty(PropertyName = "datumDuzp")]
        public string DatumDuzp { get => _DatumDuzp; set => Set(ref _DatumDuzp, value); }
        private string _DatumDuzp;
        public bool ShouldSerializeDatumDuzp() { return IsPropertyChanged(nameof(DatumDuzp)); }

        [JsonProperty(PropertyName = "datumPorizeni")]
        public string DatumPorizeni { get => _DatumPorizeni; set => Set(ref _DatumPorizeni, value); }
        private string _DatumPorizeni;
        public bool ShouldSerializeDatumPorizeni() { return IsPropertyChanged(nameof(DatumPorizeni)); }

        [JsonProperty(PropertyName = "datumSplatnosti")]
        public string DatumSplatnosti { get => _DatumSplatnosti; set => Set(ref _DatumSplatnosti, value); }
        private string _DatumSplatnosti;
        public bool ShouldSerializeDatumSplatnosti() { return IsPropertyChanged(nameof(DatumSplatnosti)); }

        [JsonProperty(PropertyName = "dobropisId")]
        public int? DobropisId { get => _DobropisId; set => Set(ref _DobropisId, value); }
        private int? _DobropisId;
        public bool ShouldSerializeDobropisId() { return IsPropertyChanged(nameof(DobropisId)); }

        [JsonProperty(PropertyName = "dobropisIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string DobropisIdEx { get => _DobropisIdEx; set => Set(ref _DobropisIdEx, value); }
        private string _DobropisIdEx;
        public bool ShouldSerializeDobropisIdEx() { return IsPropertyChanged(nameof(DobropisIdEx)); }

        [JsonProperty(PropertyName = "konstantniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string KonstantniSymbol { get => _KonstantniSymbol; set => Set(ref _KonstantniSymbol, value); }
        private string _KonstantniSymbol;
        public bool ShouldSerializeKonstantniSymbol() { return IsPropertyChanged(nameof(KonstantniSymbol)); }

        [JsonProperty(PropertyName = "organizace")]
        public OrganizaceGetResponseElement OrganizaceOdberatel { get => _OrganizaceOdberatel; set => Set(ref _OrganizaceOdberatel, value); }
        private OrganizaceGetResponseElement _OrganizaceOdberatel;
        public bool ShouldSerializeOrganizaceOdberatel() { return IsPropertyChanged(nameof(OrganizaceOdberatel)); }

        [JsonProperty(PropertyName = "organizace2")]
        public OrganizaceGetResponseElement OrganizacePrijemce { get => _OrganizacePrijemce; set => Set(ref _OrganizacePrijemce, value); }
        private OrganizaceGetResponseElement _OrganizacePrijemce;
        public bool ShouldSerializeOrganizacePrijemce() { return IsPropertyChanged(nameof(OrganizacePrijemce)); }

        [JsonProperty(PropertyName = "poznamka")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Poznamka { get => _Poznamka; set => Set(ref _Poznamka, value); }
        private string _Poznamka;
        public bool ShouldSerializePoznamka() { return IsPropertyChanged(nameof(Poznamka)); }

        [JsonProperty(PropertyName = "specifickySymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string SpecifickySymbol { get => _SpecifickySymbol; set => Set(ref _SpecifickySymbol, value); }
        private string _SpecifickySymbol;
        public bool ShouldSerializeSpecifickySymbol() { return IsPropertyChanged(nameof(SpecifickySymbol)); }

        [JsonProperty(PropertyName = "typUhrady")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string TypUhrady { get => _TypUhrady; set => Set(ref _TypUhrady, value); }
        private string _TypUhrady;
        public bool ShouldSerializeTypUhrady() { return IsPropertyChanged(nameof(TypUhrady)); }

        [JsonProperty(PropertyName = "variabilniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string VariabilniSymbol { get => _VariabilniSymbol; set => Set(ref _VariabilniSymbol, value); }
        private string _VariabilniSymbol;
        public bool ShouldSerializeVariabilniSymbol() { return IsPropertyChanged(nameof(VariabilniSymbol)); }

        [JsonProperty(PropertyName = "kontaceId")]
        public int? KontaceId { get => _KontaceId; set => Set(ref _KontaceId, value); }
        private int? _KontaceId;
        public bool ShouldSerializeKontaceId() { return IsPropertyChanged(nameof(KontaceId)); }

        [JsonProperty(PropertyName = "polozky")]
        public List<Polozka> Polozky { get => _Polozky; set => Set(ref _Polozky, value); }
        private List<Polozka> _Polozky;
        public bool ShouldSerializePolozky() { return IsPropertyChanged(nameof(Polozky)); }

        [JsonProperty(PropertyName = "parovaciSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string ParovaciSymbol { get => _ParovaciSymbol; set => Set(ref _ParovaciSymbol, value); }
        private string _ParovaciSymbol;
        public bool ShouldSerializeParovaciSymbol() { return IsPropertyChanged(nameof(ParovaciSymbol)); }

        [JsonProperty(PropertyName = "podkladovaFakturaId")]
        public int? PodkladovaFakturaId { get => _PodkladovaFakturaId; set => Set(ref _PodkladovaFakturaId, value); }
        private int? _PodkladovaFakturaId;
        public bool ShouldSerializePodkladovaFakturaId() { return IsPropertyChanged(nameof(PodkladovaFakturaId)); }

        [JsonProperty(PropertyName = "podkladovaFakturaIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PodkladovaFakturaIdEx { get => _PodkladovaFakturaIdEx; set => Set(ref _PodkladovaFakturaIdEx, value); }
        private string _PodkladovaFakturaIdEx;
    }

    public class CreditNotePostPutResponse : CreditNoteGetResponseElement
    {
        /// <summary>
        /// CZ: Chybové hlášky
        /// </summary>
        [JsonProperty(PropertyName = "errors")]
        public List<string> errors;
    }
}
