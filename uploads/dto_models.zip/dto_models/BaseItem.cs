public class BaseItem
{
    private readonly HashSet<string> _changedProperties = new HashSet<string>();

    /// <summary>
    /// Assigns a new value to the property and remember the fact the property was changed. 
    /// </summary>
    /// <typeparam name="T">The type of the property that changed.</typeparam>
    /// <param name="field">The field storing the property's value.</param>
    /// <param name="newValue">The property's value after the change occurred.</param>
    /// <param name="propertyName">(optional) The name of the property that changed. If unspecified <see cref="CallerMemberNameAttribute"/> is used.
    /// </param>
    protected void Set<T>(ref T field, T newValue, [/*System.Runtime.CompilerServices*/CallerMemberName] string propertyName = null)
    {
        field = newValue;
        _changedProperties.Add(propertyName);
    }

    /// <summary>
    /// Gets true if property with name <paramref name="propertyName"/> was changed.
    /// </summary>
    /// <param name="propertyName">Name of property. Use nameof(item.MyProperty) to get property name.</param>
    /// <returns></returns>
    public bool IsPropertyChanged(string propertyName)
    {
        if (String.IsNullOrWhiteSpace(propertyName)) return false;
        return _changedProperties.Contains(propertyName);
    }
}