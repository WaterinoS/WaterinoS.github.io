﻿using System;
using System.Collections.Generic;

using Newtonsoft.Json;

using Noris.LCS.WebApi.Globals.Contracts;

namespace Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts
{
    /// <summary>
    /// API GET Customer/Pantheon/Platce QUERY parameters
    /// </summary>
    public class PayerGetRequest : BaseItem
    {
        /// <summary>
        /// CZ: Kód knihy poplatku
        /// </summary>
        /// <example>777</example>
        [JsonProperty(PropertyName = "KodKnihy")]
        public int? KodKnihy { get; set; }
        /// <summary>
        /// CZ: Interní identifikátor Plátce (parametr má přednost před ostatními parametry)
        /// </summary>
        /// <example>781254</example>
        [JsonProperty(PropertyName = "PlatceId")]
        public int? PlatceId { get; set; }
        /// <summary>
        /// CZ: Externí identifikátor Plátce (parametr má přednost před ostatními parametry)
        /// </summary>
        /// <example>PIX_0001</example>
        [JsonProperty(PropertyName = "PlatceIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PlatceIdEx { get; set; }
        /// <summary>
        /// CZ: Variabilní symbol
        /// </summary>
        /// <example>7770000001</example>
        [JsonProperty(PropertyName = "VariabilniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string VariabilniSymbol { get; set; }

        /// <summary>
        /// CZ: Rodné číslo
        /// </summary>
        /// <example>010101/0001</example>
        [JsonProperty(PropertyName = "RodneCislo")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string RodneCislo { get; set; }

        /// <summary>
        /// CZ: Číslo dokladu (max. 30 znaků)
        /// </summary>
        /// <example>112233445566</example>
        [JsonProperty(PropertyName = "CisloDokladu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string CisloDokladu { get; set; }
        /// <summary>
        /// CZ: Typ dokladu - občanský průkaz (O) nebo cestovní pas (C)
        /// </summary>
        /// <example>C</example>
        [JsonProperty(PropertyName = "TypDokladu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string TypDokladu { get; set; }
        /// <summary>
        /// CZ: Datum narození (formát rrrr-mm-dd)
        /// </summary>
        /// <example>2001-01-29</example>
        [JsonProperty(PropertyName = "DatumNarozeni")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string DatumNarozeni { get; set; }
        /// <summary>
        /// CZ: DIČ
        /// </summary>
        /// <example>CZ11111111111</example>
        [JsonProperty(PropertyName = "Dic")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Dic { get; set; }
        /// <summary>
        /// CZ: IČ
        /// </summary>
        /// <example>22222222222</example>
        [JsonProperty(PropertyName = "Ico")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Ico { get; set; }
        /// <summary>
        /// CZ: Jméno
        /// </summary>
        /// <example>Josef</example>
        [JsonProperty(PropertyName = "Jmeno")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Jmeno { get; set; }
        /// <summary>
        /// CZ: Příjmení
        /// </summary>
        /// <example>Novák</example>
        [JsonProperty(PropertyName = "Prijmeni")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Prijmeni { get; set; }
        /// <summary>
        /// CZ: Název doplňující
        /// </summary>
        /// <example></example>
        [JsonProperty(PropertyName = "NazevDoplnujici")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string NazevDoplnujici { get; set; }
        /// <summary>
        /// CZ: Název organizace
        /// </summary>
        /// <example></example>
        [JsonProperty(PropertyName = "NazevOrganizace")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string NazevOrganizace { get; set; }
        /// <summary>
        /// CZ: Externí identifikátor organizace
        /// </summary>
        /// <example></example>
        [JsonProperty(PropertyName = "OrganizaceIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string OrganizaceIdEx { get; set; }
        /// <summary>
        /// CZ: Adresa
        /// </summary>
        [JsonProperty(PropertyName = "Adresa")]
        public AdresaSearch Adresa { get; set; }

        [JsonIgnore]
        public bool MaAdresaHodnoty
        {
            get
            {
                return Adresa != null && (
                    !string.IsNullOrEmpty(Adresa.Ulice) ||
                    !string.IsNullOrEmpty(Adresa.Obec) ||
                    !string.IsNullOrEmpty(Adresa.Psc) ||
                    !string.IsNullOrEmpty(Adresa.CastObce) ||
                    !string.IsNullOrEmpty(Adresa.PismenoCo) ||
                    Adresa.IdCentralniReg > 0 ||
                    Adresa.CisloCp > 0 ||
                    Adresa.CisloCo > 0
                );
            }
        }
    }

    public class PayerInvalidateGetRequest
    {
        /// <summary>
        /// CZ: Datum ukončení
        /// </summary>
        /// <example>2021-12-31</example>
        [JsonProperty(PropertyName = "DatumUkonceni")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string DatumUkonceni { get; set; }
        /// <summary>
        /// CZ: Poznámka
        /// </summary>
        /// <example>Poznámka</example>
        [JsonProperty(PropertyName = "Poznamka")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Poznamka { get; set; }
    }

    public class DogPayerGetRequest
    {
        /// <summary>
        /// Číslo známky. 
        /// </summary>
        /// <example>501</example>
        [JsonProperty(PropertyName = "znamka")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string znamka { get; set; }

        /// <summary>
        /// Evidenční čislo čipu. 
        /// </summary>
        /// <example>622F24</example>
        [JsonProperty(PropertyName = "cip")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string cip { get; set; }
    }

    /// <summary>
    /// API GET Customer/Pantheon/Platce RESPONSE
    /// API GET Customer/Pantheon/Platce/{id} RESPONSE
    /// </summary>
    public class PayerGetResponse
    {
        /// <summary>
        /// CZ: Kolekce plátců.
        /// </summary>
        public List<PayerGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class PayerGetResponseElement : BaseItem
    {
        /// <summary>
        /// CZ: Interní číslo
        /// </summary>
        [JsonIgnore]
        [JsonProperty(PropertyName = "recordNumber")]
        public int? RecordNumber { get; set; }
        /// <summary>
        /// CZ: Interní číslo
        /// </summary>
        [JsonIgnore]
        [JsonProperty(PropertyName = "reference")]
        public string Reference { get; set; }
        /// <summary>
        /// CZ: Název plátce
        /// </summary>
        [JsonIgnore]
        [JsonProperty(PropertyName = "nazevPlatce")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string NazevPlatce { get; set; }
        /// <summary>
        /// CZ: Celkem za předpisy
        /// </summary>
        [JsonProperty(PropertyName = "celkemZaPredpisy")]
        public decimal? CelkemZaPredpisy { get; set; }
        /// <summary>
        /// CZ: Kód knihy
        /// </summary>
        [JsonProperty(PropertyName = "kodKnihy")]
        public int? KodKnihy { get; set; }
        /// <summary>
        /// CZ: Interní číslo
        /// </summary>
        [JsonProperty(PropertyName = "platceId")]
        public int? PlatceId { get; set; }
        /// <summary>
        /// CZ: Interní číslo
        /// </summary>
        [JsonProperty(PropertyName = "platceIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PlatceIdEx { get; set; }
        /// <summary>
        /// CZ: Platnost do
        /// </summary>
        [JsonProperty(PropertyName = "platnostDo")]
        public DateTime? PlatnostDo { get; set; }
        /// <summary>
        /// CZ: Platnost od
        /// </summary>
        [JsonProperty(PropertyName = "platnostOd")]
        public DateTime? PlatnostOd { get; set; }
        /// <summary>
        /// CZ: Poznámka
        /// </summary>
        [JsonProperty(PropertyName = "poznamka")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Poznamka { get; set; }
        /// <summary>
        /// CZ: Specifický symbol
        /// </summary>
        [JsonProperty(PropertyName = "specifickySymbol")]
        public decimal? SpecifickySymbol { get; set; }

        /// <summary>
        /// CZ: Spojovací číslo
        /// </summary>
        [JsonProperty(PropertyName = "spojovaciCislo")]
        public decimal? SpojovaciCislo { get; set; }
        /// <summary>
        /// CZ: Variabilní symbol
        /// </summary>
        [JsonProperty(PropertyName = "variabilniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string VariabilniSymbol { get; set; }
        /// <summary>
        /// CZ: Zbývá za předpisy
        /// </summary>
        [JsonProperty(PropertyName = "zbyvaZaPredpisy")]
        public decimal? ZbyvaZaPredpisy { get; set; }
        /// <summary>
        /// CZ: Plátce
        /// </summary>
        [JsonProperty(PropertyName = "organizace")]
        public OrganizaceGetResponseElement Organizace { get; set; }
    }

    /// <summary>
    /// API POST|PUT Customer/Pantheon/Platce REQUEST
    /// </summary>
    public class PayerPostPutRequest : BaseItem
    {
        /// <summary>
        /// CZ: Kód knihy poplatku
        /// </summary>
        /// <example>777</example>
        [JsonRequired]
        [JsonProperty(PropertyName = "KodKnihy")]
        public int? KodKnihy { get; set; }

        /// <summary>
        /// CZ: Interní identifikátor Plátce (parametr má přednost před ostatními parametry)
        /// </summary>
        /// <example>781254</example>
        [JsonProperty(PropertyName = "PlatceId")]
        public int? PlatceId { get; set; }
        /// <summary>
        /// CZ: Externí identifikátor Plátce (parametr má přednost před ostatními parametry)
        /// </summary>
        /// <example>PIX_0001</example>
        [JsonRequired]
        [JsonProperty(PropertyName = "PlatceIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PlatceIdEx { get; set; }
        /// <summary>
        /// CZ: Platnost do
        /// </summary>
        /// <example>2021-12-31</example>
        [JsonProperty(PropertyName = "PlatnostDo")]
        public DateTime? PlatnostDo { get; set; }
        /// <summary>
        /// CZ: Platnost od
        /// </summary>
        /// <example>2021-01-01</example>
        [JsonProperty(PropertyName = "PlatnostOd")]
        public DateTime? PlatnostOd { get; set; }
        /// <summary>
        /// CZ: Poznámka
        /// </summary>
        /// <example>poznámka</example>
        [JsonProperty(PropertyName = "Poznamka")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Poznamka { get; set; }
        /// <summary>
        /// CZ: Spojovací číslo
        /// </summary>
        /// <example>1234567890</example>
        [JsonProperty(PropertyName = "SpojovaciCislo")]
        public decimal? SpojovaciCislo { get; set; }
        /// <summary>
        /// CZ: Specifický symbol
        /// </summary>
        /// <example>1234567890</example>
        [JsonRequired]
        [JsonProperty(PropertyName = "SpecifickySymbol")]
        public decimal? SpecifickySymbol { get; set; }
        /// <summary>
        /// CZ: Variabilní symbol
        /// </summary>
        /// <example>1234567890</example>
        [JsonRequired]
        [JsonProperty(PropertyName = "VariabilniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string VariabilniSymbol { get; set; }
        /// <summary>
        /// CZ: Organizace (osoba) Plátce
        /// </summary>
        [JsonRequired]
        [JsonProperty(PropertyName = "Organizace")]
        public OrganizacePostPutRequest Organizace { get; set; }

        /// <summary>
        /// CZ: Platce Org.
        /// </summary>
        [JsonIgnore]
        public OrganizaceGetResponseElement platceOrganizace { get; set; }
    }

    /// <summary>
    /// API POST|PUT Customer/Pantheon/Platce RESPONSE
    /// </summary>
    public class PayerPostPutResponse : PayerGetResponseElement
    {
        /// <summary>
        /// CZ: Chybové hlášky
        /// </summary>
        [JsonProperty(PropertyName = "errors")]
        public List<string> errors;
    }
}
