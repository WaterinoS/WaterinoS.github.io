﻿using System;
using System.Collections.Generic;
using System.Text;

using Newtonsoft.Json;

using Noris.LCS.WebApi.Globals.Contracts;

namespace Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts
{
    public class PaymentTypeHeaderBase : BaseItem
    {
        [JsonProperty(PropertyName = "kod")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Kod { get => _Kod; set => Set(ref _Kod, value); }
        private string _Kod;
        public bool ShouldSerializeKod() { return IsPropertyChanged(nameof(Kod)); }

        [JsonProperty(PropertyName = "popis")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Popis { get => _Popis; set => Set(ref _Popis, value); }
        private string _Popis;
        public bool ShouldSerializePopis() { return IsPropertyChanged(nameof(Popis)); }
    }

    /// <summary>
    /// API GET Customer/Pantheon/CiselnikTypUhrady RESPONSE
    /// </summary>
    public class PaymentTypeGetResponse
    {
        /// <summary>
        /// CZ: Kolekce typů úhrad.
        /// </summary>
        public List<PaymentTypeGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class PaymentTypeGetResponseElement : PaymentTypeHeaderBase
    {
    }
}
