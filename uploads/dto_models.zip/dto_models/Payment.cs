﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

using Newtonsoft.Json;
using Noris.LCS.WebApi.Globals.Contracts;

namespace Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts
{
    #region Uhrada/Faktura
    /// <summary>
    /// API GET Customer/Pantheon/Uhrada/Faktura QUERY parameters
    /// </summary>
    public class PaymentInvoiceGetRequest : BaseItem
    {
        [JsonProperty(PropertyName = "fakturaId")]
        public int? FakturaId { get => _FakturaId; set => Set(ref _FakturaId, value); }
        private int? _FakturaId;
        public bool ShouldSerializeFakturaId() { return IsPropertyChanged(nameof(FakturaId)); }

        [JsonProperty(PropertyName = "fakturaIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string FakturaIdEx { get => _FakturaIdEx; set => Set(ref _FakturaIdEx, value); }
        private string _FakturaIdEx;
        public bool ShouldSerializeFakturaIdEx() { return IsPropertyChanged(nameof(FakturaIdEx)); }

        [JsonProperty(PropertyName = "organizace")]
        public OrganizaceSearch Organizace { get => _Organizace; set => Set(ref _Organizace, value); }
        private OrganizaceSearch _Organizace;
        public bool ShouldSerializeOrganizace() { return IsPropertyChanged(nameof(Organizace)); }

        [JsonProperty(PropertyName = "variabilniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string VariabilniSymbol { get => _VariabilniSymbol; set => Set(ref _VariabilniSymbol, value); }
        private string _VariabilniSymbol;
        public bool ShouldSerializeVariabilniSymbol() { return IsPropertyChanged(nameof(VariabilniSymbol)); }
    }
    #endregion Uhrada/Faktura

    #region Uhrada/Dobropis
    /// <summary>
    /// API GET Customer/Pantheon/Uhrada/Dobropis QUERY parameters
    /// </summary>
    public class PaymentCreditNoteGetRequest : BaseItem
    {
        [JsonProperty(PropertyName = "dobropisId")]
        public int? DobropisId { get => _DobropisId; set => Set(ref _DobropisId, value); }
        private int? _DobropisId;
        public bool ShouldSerializeDobropisId() { return IsPropertyChanged(nameof(DobropisId)); }

        [JsonProperty(PropertyName = "dobropisIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string DobropisIdEx { get => _DobropisIdEx; set => Set(ref _DobropisIdEx, value); }
        private string _DobropisIdEx;
        public bool ShouldSerializeDobropisIdEx() { return IsPropertyChanged(nameof(DobropisIdEx)); }

        [JsonProperty(PropertyName = "organizace")]
        public OrganizaceSearch Organizace { get => _Organizace; set => Set(ref _Organizace, value); }
        private OrganizaceSearch _Organizace;
        public bool ShouldSerializeOrganizace() { return IsPropertyChanged(nameof(Organizace)); }

        [JsonProperty(PropertyName = "variabilniSymbol")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string VariabilniSymbol { get => _VariabilniSymbol; set => Set(ref _VariabilniSymbol, value); }
        private string _VariabilniSymbol;
        public bool ShouldSerializeVariabilniSymbol() { return IsPropertyChanged(nameof(VariabilniSymbol)); }
    }
    #endregion Uhrada/Dobropis

    #region Uhrada/Predpis
    /// <summary>
    /// API GET Customer/Pantheon/Uhrada/Predpis QUERY parameters
    /// </summary>
    public class PaymentPayerprescriptionGetRequest : BaseItem
    {
        [JsonProperty(PropertyName = "kodKnihy")]
        public int? KodKnihy { get => _KodKnihy; set => Set(ref _KodKnihy, value); }
        private int? _KodKnihy;
        public bool ShouldSerializeKodKnihy() { return IsPropertyChanged(nameof(KodKnihy)); }

        [JsonProperty(PropertyName = "predpisId")]
        public int? PredpisId { get => _PredpisId; set => Set(ref _PredpisId, value); }
        private int? _PredpisId;
        public bool ShouldSerializePredpisId() { return IsPropertyChanged(nameof(PredpisId)); }

        [JsonProperty(PropertyName = "predpisIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PredpisIdEx { get => _PredpisIdEx; set => Set(ref _PredpisIdEx, value); }
        private string _PredpisIdEx;
        public bool ShouldSerializePredpisIdEx() { return IsPropertyChanged(nameof(PredpisIdEx)); }

        [JsonProperty(PropertyName = "platceId")]
        public int? PlatceId { get => _PlatceId; set => Set(ref _PlatceId, value); }
        private int? _PlatceId;
        public bool ShouldSerializePlatceId() { return IsPropertyChanged(nameof(PlatceId)); }

        [JsonProperty(PropertyName = "platceIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PlatceIdEx { get => _PlatceIdEx; set => Set(ref _PlatceIdEx, value); }
        private string _PlatceIdEx;       
        public bool ShouldSerializePlatceIdEx() { return IsPropertyChanged(nameof(PlatceIdEx)); }
    }
    #endregion Uhrada/Predpis

    #region Uhrada/Preplatek
    /// <summary>
    /// API GET Customer/Pantheon/Uhrada/Preplatek QUERY parameters
    /// </summary>
    public class PaymentOverpaymentGetRequest : BaseItem
    {
        [JsonProperty(PropertyName = "kodKnihy")]
        public int? KodKnihy { get => _KodKnihy; set => Set(ref _KodKnihy, value); }
        private int? _KodKnihy;
        public bool ShouldSerializeKodKnihy() { return IsPropertyChanged(nameof(KodKnihy)); }

        [JsonProperty(PropertyName = "preplatekId")]
        public int? PreplatekId { get => _PreplatekId; set => Set(ref _PreplatekId, value); }
        private int? _PreplatekId;
        public bool ShouldSerializePreplatekId() { return IsPropertyChanged(nameof(PreplatekId)); }

        [JsonProperty(PropertyName = "preplatekIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PreplatekIdEx { get => _PreplatekIdEx; set => Set(ref _PreplatekIdEx, value); }
        private string _PreplatekIdEx;
        public bool ShouldSerializePreplatekIdEx() { return IsPropertyChanged(nameof(PreplatekIdEx)); }

        [JsonProperty(PropertyName = "platceId")]
        public int? PlatceId { get => _PlatceId; set => Set(ref _PlatceId, value); }
        private int? _PlatceId;
        public bool ShouldSerializePlatceId() { return IsPropertyChanged(nameof(PlatceId)); }

        [JsonProperty(PropertyName = "platceIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PlatceIdEx { get => _PlatceIdEx; set => Set(ref _PlatceIdEx, value); }
        private string _PlatceIdEx;
        public bool ShouldSerializePlatceIdEx() { return IsPropertyChanged(nameof(PlatceIdEx)); }
    }
    #endregion Uhrada/Preplatek

    #region Uhrada/OdDatumu
    /// <summary>
    /// API GET Customer/Pantheon/Uhrada/OdDatumu QUERY parameters
    /// </summary>
    public class PaymentSinceDateGetRequest : BaseItem
    {
        [JsonProperty(PropertyName = "datumOd")]
        public DateTime? DatumOd { get => _DatumOd; set => Set(ref _DatumOd, value); }
        private DateTime? _DatumOd;
        public bool ShouldSerializeDatumOd() { return IsPropertyChanged(nameof(DatumOd)); }

        [JsonProperty(PropertyName = "datumDo")]
        public DateTime? DatumDo { get => _DatumDo; set => Set(ref _DatumDo, value); }
        private DateTime? _DatumDo;
        public bool ShouldSerializeDatumDo() { return IsPropertyChanged(nameof(DatumDo)); }

        /// <summary>
        /// CZ: Kódy knih oddělené čárkou.
        /// </summary>
        [JsonProperty(PropertyName = "kodKnihy")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string KodKnihy { get => _KodKnihy; set => Set(ref _KodKnihy, value); }
        private string _KodKnihy;
        public bool ShouldSerializeKodKnihy() { return IsPropertyChanged(nameof(KodKnihy)); }

        [JsonIgnore]
        public List<int> kodyKnih => !string.IsNullOrEmpty(KodKnihy) ? KodKnihy.Split(',').Select(Int32.Parse).ToList() : new List<int>();
    }
    #endregion Uhrada/OdDatumu

    #region Uhrada/Smazana/OdDatumu
    /// <summary>
    /// API GET Customer/Pantheon/Uhrada/Smazana/OdDatumu QUERY parameters
    /// </summary>
    public class PaymentDeletedSinceDateGetRequest : PaymentSinceDateGetRequest
    {
    }
    #endregion Uhrada/Smazana/OdDatumu

    /// <summary>
    /// API GET Customer/Pantheon/Uhrada RESPONSE
    /// </summary>
    public class PaymentGetResponse
    {
        /// <summary>
        /// CZ: Kolekce organizací.
        /// </summary>
        public List<PaymentGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class PaymentGetResponseElement : BaseItem
    {
        [JsonProperty(PropertyName = "castka")]
        public decimal? Castka { get => _Castka; set => Set(ref _Castka, value); }
        private decimal? _Castka;
        public bool ShouldSerializeCastka() { return IsPropertyChanged(nameof(Castka)); }

        [JsonProperty(PropertyName = "datumUhrady")]
        public DateTime? DatumUhrady { get => _DatumUhrady; set => Set(ref _DatumUhrady, value); }
        private DateTime? _DatumUhrady;
        public bool ShouldSerializeDatumUhrady() { return IsPropertyChanged(nameof(DatumUhrady)); }

        [JsonProperty(PropertyName = "datumSmazaniUhrady")]
        public DateTime? DatumSmazaniUhrady { get => _DatumSmazaniUhrady; set => Set(ref _DatumSmazaniUhrady, value); }
        private DateTime? _DatumSmazaniUhrady;
        public bool ShouldSerializeDatumSmazaniUhrady() { return IsPropertyChanged(nameof(DatumSmazaniUhrady)); }

        [JsonProperty(PropertyName = "hradiciDokladId")]
        public int? HradiciDokladId { get => _HradiciDokladId; set => Set(ref _HradiciDokladId, value); }
        private int? _HradiciDokladId;
        public bool ShouldSerializeHradiciDokladId() { return IsPropertyChanged(nameof(HradiciDokladId)); }

        [JsonProperty(PropertyName = "hradiciDokladCislo")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string HradiciDokladCislo { get => _HradiciDokladCislo; set => Set(ref _HradiciDokladCislo, value); }
        private string _HradiciDokladCislo;
        public bool ShouldSerializeHradiciDokladCislo() { return IsPropertyChanged(nameof(HradiciDokladCislo)); }

        [JsonProperty(PropertyName = "hrazenyDokladId")]
        public int? HrazenyDokladId { get => _HrazenyDokladId; set => Set(ref _HrazenyDokladId, value); }
        private int? _HrazenyDokladId;
        public bool ShouldSerializeHrazenyDokladId() { return IsPropertyChanged(nameof(HrazenyDokladId)); }

        [JsonProperty(PropertyName = "hrazenyDokladIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string HrazenyDokladIdEx { get => _HrazenyDokladIdEx; set => Set(ref _HrazenyDokladIdEx, value); }
        private string _HrazenyDokladIdEx;
        public bool ShouldSerializeHrazenyDokladIdEx() { return IsPropertyChanged(nameof(HrazenyDokladIdEx)); }

        [JsonProperty(PropertyName = "typUhrady")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string TypUhrady { get => _TypUhrady; set => Set(ref _TypUhrady, value); }
        private string _TypUhrady;
        public bool ShouldSerializeTypUhrady() { return IsPropertyChanged(nameof(TypUhrady)); }

        [JsonProperty(PropertyName = "uhradaId")]
        public int? UhradaId { get => _UhradaId; set => Set(ref _UhradaId, value); }
        private int? _UhradaId;
        public bool ShouldSerializeUhradaId() { return IsPropertyChanged(nameof(UhradaId)); }
    }
}
