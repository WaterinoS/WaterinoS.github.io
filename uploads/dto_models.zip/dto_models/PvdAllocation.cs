﻿using System.Collections.Generic;
using Newtonsoft.Json;
using Noris.LCS.WebApi.Globals.Contracts;

namespace Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts
{
    /// <summary>
    /// API GET Customer/Pantheon/KontacePrvodokladu RESPONSE
    /// </summary>
    public class PvdAllocationGetResponse
    {
        /// <summary>
        /// CZ: Kolekce sazeb dph.
        /// </summary>
        public List<PvdAllocationGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class PvdAllocationGetResponseElement : BaseItem
    {
        [JsonProperty(PropertyName = "kontaceId")]
        public int? kontaceId { get => _kontaceId; set => Set(ref _kontaceId, value); }
        private int? _kontaceId;
        public bool ShouldSerializekontaceId() { return IsPropertyChanged(nameof(kontaceId)); }

        [JsonProperty(PropertyName = "interniCislo")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string interniCislo { get => _interniCislo; set => Set(ref _interniCislo, value); }
        private string _interniCislo;
        public bool ShouldSerializeinterniCislo() { return IsPropertyChanged(nameof(interniCislo)); }

        [JsonProperty(PropertyName = "kontaceNazev")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string kontaceNazev { get => _kontaceNazev; set => Set(ref _kontaceNazev, value); }
        private string _kontaceNazev;
        public bool ShouldSerializekontaceNazev() { return IsPropertyChanged(nameof(kontaceNazev)); }

        [JsonProperty(PropertyName = "sbornikNazev")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string sbornikNazev { get => _sbornikNazev; set => Set(ref _sbornikNazev, value); }
        private string _sbornikNazev;
        public bool ShouldSerializesbornikNazev() { return IsPropertyChanged(nameof(sbornikNazev)); }
    }

    public class PvdAllocationGetRequest : BaseItem
    {
        [JsonProperty(PropertyName = "interniCislo")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string interniCislo { get => _interniCislo; set => Set(ref _interniCislo, value); }
        private string _interniCislo;
        public bool ShouldSerializeinterniCislo() { return IsPropertyChanged(nameof(interniCislo)); }

        [JsonProperty(PropertyName = "kontaceNazev")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string kontaceNazev { get => _kontaceNazev; set => Set(ref _kontaceNazev, value); }
        private string _kontaceNazev;
        public bool ShouldSerializekontaceNazev() { return IsPropertyChanged(nameof(kontaceNazev)); }
    }
}
