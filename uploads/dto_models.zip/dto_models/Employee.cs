﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Newtonsoft.Json;
using Noris.LCS.WebApi.Globals.Contracts;

namespace Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts
{
    /// <summary>
    /// API GET Customer/Pantheon/Zamestnanec QUERY parameters
    /// </summary>
    public class EmployeeGetRequest : BaseItem
    {
        [JsonProperty(PropertyName = "osobniCislo")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string OsobniCislo { get => _OsobniCislo; set => Set(ref _OsobniCislo, value); }
        private string _OsobniCislo;
        public bool ShouldSerializeOsobniCislo() { return IsPropertyChanged(nameof(OsobniCislo)); }

        [JsonProperty(PropertyName = "login")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Login { get => _Login; set => Set(ref _Login, value); }
        private string _Login;
        public bool ShouldSerializeLogin() { return IsPropertyChanged(nameof(Login)); }

        [JsonProperty(PropertyName = "jmeno")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Jmeno { get => _Jmeno; set => Set(ref _Jmeno, value); }
        private string _Jmeno;
        public bool ShouldSerializeJmeno() { return IsPropertyChanged(nameof(Jmeno)); }

        [JsonProperty(PropertyName = "prijmeni")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Prijmeni { get => _Prijmeni; set => Set(ref _Prijmeni, value); }
        private string _Prijmeni;
        public bool ShouldSerializePrijmeni() { return IsPropertyChanged(nameof(Prijmeni)); }
    }

    /// <summary>
    /// API GET Customer/Pantheon/Zamestnanec RESPONSE
    /// API GET Customer/Pantheon/Zamestnanec/{id} RESPONSE
    /// </summary>
    public class EmployeeGetResponse
    {
        /// <summary>
        /// CZ: Kolekce organizací.
        /// </summary>
        public List<EmployeeGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class EmployeeGetResponseElement : BaseItem
    {
        [JsonIgnore]
        [JsonProperty(PropertyName = "recordNumber")]
        public int? RecordNumber { get => _RecordNumber; set => Set(ref _RecordNumber, value); }
        private int? _RecordNumber;
        public bool ShouldSerializeRecordNumber() { return IsPropertyChanged(nameof(RecordNumber)); }

        [JsonProperty(PropertyName = "osobniCislo")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string OsobniCislo { get => _OsobniCislo; set => Set(ref _OsobniCislo, value); }
        private string _OsobniCislo;
        public bool ShouldSerializeOsobniCislo() { return IsPropertyChanged(nameof(OsobniCislo)); }

        [JsonProperty(PropertyName = "zamestnanecId")]
        public int? ZamestnanecId { get => _ZamestnanecId; set => Set(ref _ZamestnanecId, value); }
        private int? _ZamestnanecId;
        public bool ShouldSerializeZamestnanecId() { return IsPropertyChanged(nameof(ZamestnanecId)); }

        [JsonProperty(PropertyName = "jmeno")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Jmeno { get => _Jmeno; set => Set(ref _Jmeno, value); }
        private string _Jmeno;
        public bool ShouldSerializeJmeno() { return IsPropertyChanged(nameof(Jmeno)); }

        [JsonProperty(PropertyName = "prijmeni")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
            public string Prijmeni { get => _Prijmeni; set => Set(ref _Prijmeni, value); }
        private string _Prijmeni;
        public bool ShouldSerializePrijmeni() { return IsPropertyChanged(nameof(Prijmeni)); }

        [JsonProperty(PropertyName = "login")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Login { get => _Login; set => Set(ref _Login, value); }
        private string _Login;
        public bool ShouldSerializeLogin() { return IsPropertyChanged(nameof(Login)); }

        [JsonIgnore]
        [JsonProperty(PropertyName = "utvarId")]
        public int? UtvarId { get => _UtvarId; set => Set(ref _UtvarId, value); }
        private int? _UtvarId;
        public bool ShouldSerializeUtvarId() { return IsPropertyChanged(nameof(UtvarId)); }
    }
}
