﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Noris.LCS.WebApi.App.General.Contracts.Enumerations;
using Noris.LCS.WebApi.Globals.Contracts;
using global::Noris.LCS.WebApi.App.General.Contracts;
using System.ComponentModel;

namespace Noris.Fenix.WebApi.App.Customer.Pantheon.Contracts
{
    /// <summary>
    /// Base data of company header.
    /// Common ancestor for all the GET RESPONSE + POST|PUT REQUEST objects. Suitable for simple attributes.
    /// BEWARE this is really the basic class, all the properties will be part of all the object types ment above.
    /// </summary>
    public class OrganizaceHeaderBase : BaseItem
    {
        [JsonProperty(PropertyName = "cisloOrganizace")]
        [AbsoluteDbName("lcs.organizace.cislo_subjektu")]
        public int? Id { get => _Id; set => Set(ref _Id, value); }
        private int? _Id;

        [JsonIgnore]
        [JsonProperty(PropertyName = "referenceOrganizace")]
        [AbsoluteDbName("lcs.organizace.reference_subjektu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string  Reference { get => _Reference; set => Set(ref _Reference, value); }
        private string _Reference;
        public bool ShouldSerializeReference() { return IsPropertyChanged(nameof(Reference)); }

        [JsonProperty(PropertyName = "nazevZkraceny")]
        [AbsoluteDbName("lcs.organizace.nazev_zkraceny")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  NazevZkraceny { get => _NazevZkraceny; set => Set(ref _NazevZkraceny, value); }
        private string _NazevZkraceny;
        public bool ShouldSerializeNazevZkraceny() { return IsPropertyChanged(nameof(NazevZkraceny)); }

        [JsonProperty(PropertyName = "nazevDoplnujici")]
        [AbsoluteDbName("lcs.organizace.doplnujici_nazev")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  NazevDoplnujici { get => _NazevDoplnujici; set => Set(ref _NazevDoplnujici, value); }
        private string _NazevDoplnujici;
        public bool ShouldSerializeNazevDoplnujici() { return IsPropertyChanged(nameof(NazevDoplnujici)); }

        [JsonProperty(PropertyName = "jmeno")]
        [AbsoluteDbName("lcs.organizace.jmeno")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  Jmeno { get => _Jmeno; set => Set(ref _Jmeno, value); }
        private string _Jmeno;
        public bool ShouldSerializeJmeno() { return IsPropertyChanged(nameof(Jmeno)); }

        [JsonProperty(PropertyName = "prijmeni")]
        [AbsoluteDbName("lcs.organizace.prijmeni")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  Prijmeni { get => _Prijmeni; set => Set(ref _Prijmeni, value); }
        private string _Prijmeni;
        public bool ShouldSerializePrijmeni() { return IsPropertyChanged(nameof(Prijmeni)); }

        [JsonProperty(PropertyName = "ico")]
        [AbsoluteDbName("lcs.organizace.íco")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  Ico { get => _Ico; set => Set(ref _Ico, value); }
        private string _Ico;
        public bool ShouldSerializeIco() { return IsPropertyChanged(nameof(Ico)); }

        [JsonRequired]
        [JsonProperty(PropertyName = "nazevOrganizace")]
        [AbsoluteDbName("lcs.organizace.nazev_subjektu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  NazevOrganizace { get => _NazevOrganizace; set => Set(ref _NazevOrganizace, value); }
        private string _NazevOrganizace;
        public bool ShouldSerializeNazevOrganizace() { return IsPropertyChanged(nameof(NazevOrganizace)); }

        [JsonProperty(PropertyName = "dic")]
        [AbsoluteDbName("lcs.organizace.dic")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  Dic { get => _Dic; set => Set(ref _Dic, value); }
        private string _Dic;
        public bool ShouldSerializeDic() { return IsPropertyChanged(nameof(Dic)); }

        [JsonRequired]
        [JsonProperty(PropertyName = "pravniForma")]
        [AbsoluteDbName("lcs.organizace.pravni_forma")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  PravniForma { get => _PravniForma; set => Set(ref _PravniForma, value); }
        private string _PravniForma;
        public bool ShouldSerializePravniForma() { return IsPropertyChanged(nameof(PravniForma)); }

        [JsonProperty(PropertyName = "eMail")]
        [AbsoluteDbName("lcs.organizace.e_mail")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  Email { get => _Email; set => Set(ref _Email, value); }
        private string _Email;
        public bool ShouldSerializeEmail() { return IsPropertyChanged(nameof(Email)); }

        [JsonProperty(PropertyName = "poznamka")]
        [AbsoluteDbName("lcs.organizace.poznamka")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  Poznamka { get => _Poznamka; set => Set(ref _Poznamka, value); }
        private string _Poznamka;
        public bool ShouldSerializePoznamka() { return IsPropertyChanged(nameof(Poznamka)); }

        [JsonProperty(PropertyName = "datumNarozeni")]
        [AbsoluteDbName("lcs.organizace.datum_narozeni")]
        public DateTime? DatumNarozeni { get => _DatumNarozeni; set => Set(ref _DatumNarozeni, value); }
        private DateTime? _DatumNarozeni;
        public bool ShouldSerializeDatumNarozeni() { return IsPropertyChanged(nameof(DatumNarozeni)); }

        [JsonProperty(PropertyName = "datumUmrti")]
        [AbsoluteDbName("lcs.organizace.datum_umrti")]
        public DateTime? DatumUmrti { get => _DatumUmrti; set => Set(ref _DatumUmrti, value); }
        private DateTime? _DatumUmrti;
        public bool ShouldSerializeDatumUmrti() { return IsPropertyChanged(nameof(DatumUmrti)); }

        [JsonProperty(PropertyName = "rodneCislo")]
        [AbsoluteDbName("lcs.organizace.rodne_cislo")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  RodneCislo { get => _RodneCislo; set => Set(ref _RodneCislo, value); }
        private string _RodneCislo;
        public bool ShouldSerializeRodneCislo() { return IsPropertyChanged(nameof(RodneCislo)); }

        [JsonRequired]
        [JsonProperty(PropertyName = "organizaceIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  OrganizaceIdEx { get => _OrganizaceIdEx; set => Set(ref _OrganizaceIdEx, value); }
        private string _OrganizaceIdEx;
        public bool ShouldSerializeOrganizaceIdEx() { return IsPropertyChanged(nameof(OrganizaceIdEx)); }

        [JsonProperty(PropertyName = "platceDph")]
        [AbsoluteDbName("lcs.organizace.platce_dph")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  PlatceDph { get => _PlatceDph; set => Set(ref _PlatceDph, value); }
        private string _PlatceDph;
        public bool ShouldSerializePlatceDph() { return IsPropertyChanged(nameof(PlatceDph)); }

        [JsonIgnore]
        [JsonProperty(PropertyName = "nazevZeme")]
        [AbsoluteDbName("lcs.zeme.nazev")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  ZemeNazev { get => _ZemeNazev; set => Set(ref _ZemeNazev, value); }
        private string _ZemeNazev;
        public bool ShouldSerializeZeme() { return IsPropertyChanged(nameof(ZemeNazev)); }

        [JsonProperty(PropertyName = "idPartnera")]
        [AbsoluteDbName("lcs.organizace.id_partnera")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  IdPartnera { get => _IdPartnera; set => Set(ref _IdPartnera, value); }
        private string _IdPartnera;
        public bool ShouldSerializeIdPartnera() { return IsPropertyChanged(nameof(IdPartnera)); }

        [JsonProperty(PropertyName = "stav")]
        [AbsoluteDbName("lcs.organizace.stav")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  Stav { get => _Stav; set => Set(ref _Stav, value); }
        private string _Stav;
        public bool ShouldSerializeStav() { return IsPropertyChanged(nameof(Stav)); }

        [JsonProperty(PropertyName = "zemeId")]
        [AbsoluteDbName("lcs.zeme.iso_kod_zeme")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  ZemeCode { get => _ZemeCode; set => Set(ref _ZemeCode, value); }
        private string _ZemeCode;
        public bool ShouldSerializeZemeCode() { return IsPropertyChanged(nameof(ZemeCode)); }

        [JsonProperty(PropertyName = "adresy")]
        public IList<Adresa> Adresy { get => _Adresy; set => Set(ref _Adresy, value); }
        private IList<Adresa> _Adresy;
        public bool ShouldSerializeAdresy() { return IsPropertyChanged(nameof(Adresy)); }
    }

    /// <summary>
    /// Base data of company header.
    /// Common ancestor for all the POST|PUT REQUEST objects. Suitable for related record id's. Extends CompanyHeaderBase with simple attributes.
    /// </summary>
    public class OrganizaceHeaderPostPutBase : OrganizaceHeaderBase
    {
        
    }

    /// <summary>
    /// Base data of company header.
    /// Common ancestor for all the GET RESPONSE objects. Suitable for related record basic info's (id, number, name). Extends CompanyHeaderBase with simple attributes.
    /// </summary>
    public class OrganizaceHeaderGetBase : OrganizaceHeaderBase
    {
       
    }

    /// <summary>
    /// API GET Customer/Pantheon/Organizace QUERY parameters
    /// </summary>
    public class OrganizaceGetRequest : OrganizaceHeaderGetBase
    {
        /// <summary>
        /// CZ: Číslo dokladu
        /// </summary>
        [JsonProperty(PropertyName = "cisloDokladu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  CisloDokladu { get; set; }

        /// <summary>
        /// CZ: Typ dokladu
        /// </summary>
        [JsonProperty(PropertyName = "typDokladu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string TypDokladu { get; set; }
    }

    /// <summary>
    /// API GET Customer/Pantheon/Organizace RESPONSE
    /// API GET Customer/Pantheon/Organizace/{id} RESPONSE
    /// </summary>
    public class OrganizaceGetResponse
    {
        /// <summary>
        /// CZ: Kolekce organizací.
        /// </summary>
        public List<OrganizaceGetResponseElement> value;

        /// <summary>
        /// CZ: Celkový počet záznamů.
        /// </summary>
        public int TotalCount { get; set; } = -1;
        /// <summary>
        /// CZ: Počet záznamů.
        /// </summary>
        public int Count { get; set; } = -1;
        /// <summary>
        /// CZ: Počet stránek.
        /// </summary>
        public int PageSize { get; set; } = -1;
        /// <summary>
        /// CZ: Stránka
        /// </summary>
        public int Page { get; set; } = -1;
    }

    public class OrganizaceGetResponseElement : OrganizaceHeaderBase
    {
    }

    /// <summary>
    /// API POST|PUT Customer/Pantheon/Organizace REQUEST
    /// </summary>
    public class OrganizacePostPutRequest : OrganizaceHeaderPostPutBase
    {

    }

    /// <summary>
    /// API POST|PUT Customer/Pantheon/Organizace RESPONSE
    /// </summary>
    public class OrganizacePostPutResponse : OrganizaceGetResponseElement
    {
        /// <summary>
        /// CZ: Chybové hlášky
        /// </summary>
        [JsonProperty(PropertyName = "errors")]
        public List<string> errors;
    }

    /// <summary>
    /// CZ: Typ osoby
    /// </summary>
    public enum TypOsoby
    {
        Nenalezeno = 0,
        Fyzicka = 1,
        Pravnicka = 2,
        Soukroma = 3
    }

    public class Adresa : BaseItem
    {
        [JsonRequired]
        [JsonProperty(PropertyName = "typAdresy")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  TypAdresyNazev { get => _TypAdresyNazev; set => Set(ref _TypAdresyNazev, value); }
        private string _TypAdresyNazev;

        [JsonIgnore]
        [JsonProperty(PropertyName = "typAdresyId")]
        public int? TypAdresy { get => _TypAdresy; set => Set(ref _TypAdresy, value); }
        private int? _TypAdresy;
        public bool ShouldSerializeTypAdresy() { return IsPropertyChanged(nameof(TypAdresy)); }

        [JsonProperty(PropertyName = "cisloCo")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  CisloCo { get => _CisloCo; set => Set(ref _CisloCo, value); }
        private string _CisloCo;
        public bool ShouldSerializeCisloCo() { return IsPropertyChanged(nameof(CisloCo)); }

        [JsonProperty(PropertyName = "cisloCp")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  CisloCp { get => _CisloCp; set => Set(ref _CisloCp, value); }
        private string _CisloCp;
        public bool ShouldSerializeCisloCp() { return IsPropertyChanged(nameof(CisloCp)); }

        [JsonProperty(PropertyName = "obec")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  Obec { get => _Obec; set => Set(ref _Obec, value); }
        private string _Obec;
        public bool ShouldSerializeObec() { return IsPropertyChanged(nameof(Obec)); }

        [JsonProperty(PropertyName = "castObce")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  CastObce { get => _CastObce; set => Set(ref _CastObce, value); }
        private string _CastObce;
        public bool ShouldSerializeCastObce() { return IsPropertyChanged(nameof(CastObce)); }

        [JsonProperty(PropertyName = "mestskyObvod")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  MestskyObvod { get => _MestskyObvod; set => Set(ref _MestskyObvod, value); }
        private string _MestskyObvod;
        public bool ShouldSerializeMestskyObvod() { return IsPropertyChanged(nameof(MestskyObvod)); }

        [JsonProperty(PropertyName = "okres")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  Okres { get => _Okres; set => Set(ref _Okres, value); }
        private string _Okres;
        public bool ShouldSerializeOkres() { return IsPropertyChanged(nameof(Okres)); }

        [JsonProperty(PropertyName = "pismenoCo")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  PismenoCo { get => _PismenoCo; set => Set(ref _PismenoCo, value); }
        private string _PismenoCo;
        public bool ShouldSerializePismenoCo() { return IsPropertyChanged(nameof(PismenoCo)); }

        [JsonProperty(PropertyName = "psc")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  Psc { get => _Psc; set => Set(ref _Psc, value); }
        private string _Psc;
        public bool ShouldSerializePsc() { return IsPropertyChanged(nameof(Psc)); }

        [JsonProperty(PropertyName = "stavAdresy")]
        public int StavAdresy { get => _StavAdresy; set => Set(ref _StavAdresy, value); }

        private int _StavAdresy;
        public bool ShouldSerializeStavAdresy() { return IsPropertyChanged(nameof(StavAdresy)); }

        [JsonProperty(PropertyName = "typCislaDomovniho")]
        public int TypCislaDomovniho { get => _TypCislaDomovniho; set => Set(ref _TypCislaDomovniho, value); }
        private int _TypCislaDomovniho;
        public bool ShouldSerializeTypCislaDomovniho() { return IsPropertyChanged(nameof(TypCislaDomovniho)); }

        [JsonProperty(PropertyName = "ulice")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  Ulice { get => _Ulice; set => Set(ref _Ulice, value); }
        private string _Ulice;
        public bool ShouldSerializeUlice() { return IsPropertyChanged(nameof(Ulice)); }

        [JsonProperty(PropertyName = "organizaceIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
		public string  OrganizaceIdEx { get => _OrganizaceIdEx; set => Set(ref _OrganizaceIdEx, value); }
        private string _OrganizaceIdEx;
        public bool ShouldSerializeOrganizaceIdEx() { return IsPropertyChanged(nameof(OrganizaceIdEx)); }
    }

    /// <summary>
    /// CZ: Vstupní typ/Request pro aktualizaci adresy
    /// </summary>
    public class AdresaUpdate : Adresa
    {

    }

    /// <summary>
    /// CZ: Vstupní typ/Request pro Adresu
    /// </summary>
    public class AdresaGet : Adresa
    {
        [JsonIgnore]
        [JsonProperty(PropertyName = "recordNumber")]
        public int? RecordNumber { get => _RecordNumber; set => Set(ref _RecordNumber, value); }
        private int? _RecordNumber;
        public bool ShouldSerializeRecordNumber() { return IsPropertyChanged(nameof(RecordNumber)); }
    }

    /// <summary>
    /// CZ: Návratový typ/Response pro Adresu
    /// </summary>
    public class AdresaResponse : AdresaGet
    {
        /// <summary>
        /// CZ: Chybové hlášky
        /// </summary>
        [JsonProperty(PropertyName = "errors")]
        public List<string> errors;
    }

    /// <summary>
    /// CZ: Způsob úhrady na pokladně: H - Hotově, P - Platební kartou.
    /// </summary>
    public static class TypDokladu
    {
        /// <summary>
        /// CZ: Občanský průkaz ("O")
        /// </summary>
        public const string ObcanskyPrukaz = "O";
        /// <summary>
        /// CZ:  Cestovní pas ("C")
        /// </summary>
        public const string CestovniPas = "C";
    }

    /// <summary>
    /// CZ: Model sloužící k vyhledávání organizace
    /// </summary>
    public class OrganizaceSearch : BaseItem
    {
        [JsonProperty(PropertyName = "nazevDoplnujici")]
        [AbsoluteDbName("lcs.organizace.doplnujici_nazev")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string NazevDoplnujici { get => _NazevDoplnujici; set => Set(ref _NazevDoplnujici, value); }
        private string _NazevDoplnujici;
        public bool ShouldSerializeNazevDoplnujici() { return IsPropertyChanged(nameof(NazevDoplnujici)); }

        [JsonProperty(PropertyName = "jmeno")]
        [AbsoluteDbName("lcs.organizace.jmeno")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Jmeno { get => _Jmeno; set => Set(ref _Jmeno, value); }
        private string _Jmeno;
        public bool ShouldSerializeJmeno() { return IsPropertyChanged(nameof(Jmeno)); }

        [JsonProperty(PropertyName = "prijmeni")]
        [AbsoluteDbName("lcs.organizace.prijmeni")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Prijmeni { get => _Prijmeni; set => Set(ref _Prijmeni, value); }
        private string _Prijmeni;
        public bool ShouldSerializePrijmeni() { return IsPropertyChanged(nameof(Prijmeni)); }

        [JsonProperty(PropertyName = "ico")]
        [AbsoluteDbName("lcs.organizace.íco")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Ico { get => _Ico; set => Set(ref _Ico, value); }
        private string _Ico;
        public bool ShouldSerializeIco() { return IsPropertyChanged(nameof(Ico)); }

        [JsonProperty(PropertyName = "nazevOrganizace")]
        [AbsoluteDbName("lcs.organizace.nazev_subjektu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string NazevOrganizace { get => _NazevOrganizace; set => Set(ref _NazevOrganizace, value); }
        private string _NazevOrganizace;
        public bool ShouldSerializeNazevOrganizace() { return IsPropertyChanged(nameof(NazevOrganizace)); }

        [JsonProperty(PropertyName = "dic")]
        [AbsoluteDbName("lcs.organizace.dic")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Dic { get => _Dic; set => Set(ref _Dic, value); }
        private string _Dic;
        public bool ShouldSerializeDic() { return IsPropertyChanged(nameof(Dic)); }

        [JsonProperty(PropertyName = "pravniForma")]
        [AbsoluteDbName("lcs.organizace.pravni_forma")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PravniForma { get => _PravniForma; set => Set(ref _PravniForma, value); }
        private string _PravniForma;
        public bool ShouldSerializePravniForma() { return IsPropertyChanged(nameof(PravniForma)); }


        [JsonProperty(PropertyName = "datumNarozeni")]
        [AbsoluteDbName("lcs.organizace.datum_narozeni")]
        public DateTime? DatumNarozeni { get => _DatumNarozeni; set => Set(ref _DatumNarozeni, value); }
        private DateTime? _DatumNarozeni;
        public bool ShouldSerializeDatumNarozeni() { return IsPropertyChanged(nameof(DatumNarozeni)); }

        [JsonProperty(PropertyName = "rodneCislo")]
        [AbsoluteDbName("lcs.organizace.rodne_cislo")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string RodneCislo { get => _RodneCislo; set => Set(ref _RodneCislo, value); }
        private string _RodneCislo;
        public bool ShouldSerializeRodneCislo() { return IsPropertyChanged(nameof(RodneCislo)); }

        [JsonProperty(PropertyName = "organizaceIdEx")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string OrganizaceIdEx { get => _OrganizaceIdEx; set => Set(ref _OrganizaceIdEx, value); }
        private string _OrganizaceIdEx;
        public bool ShouldSerializeOrganizaceIdEx() { return IsPropertyChanged(nameof(OrganizaceIdEx)); }

        /// <summary>
        /// CZ: Číslo dokladu
        /// </summary>
        [JsonProperty(PropertyName = "cisloDokladu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string CisloDokladu { get; set; }

        /// <summary>
        /// CZ: Typ dokladu
        /// </summary>
        [JsonProperty(PropertyName = "typDokladu")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string TypDokladu { get; set; }
    }

    public class AdresaSearch
    {
        /// <summary>
        /// Nazev ulice
        /// </summary>
        /// <example>Nefritová</example>
        [JsonProperty(PropertyName = "Ulice")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Ulice { get; set; }

        /// <summary>
        /// Název obce
        /// </summary>
        /// <example>Plzeň</example>
        [JsonProperty(PropertyName = "Obec")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Obec { get; set; }
        /// <summary>
        /// PSČ
        /// </summary>
        /// <example>32300</example>
        [JsonProperty(PropertyName = "Psc")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Psc { get; set; }
        /// <summary>
        /// Část obce
        /// </summary>
        /// <example>Bolevec</example>
        [JsonProperty(PropertyName = "CastObce")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string CastObce { get; set; }
        /// <summary>
        /// Číslo popisné (domovní)
        /// </summary>
        /// <example>263</example>
        //[MaxLength(Constants.MaxDelkaCisPopisne, ErrorMessage = "Překročena maximální délka hodnoty atributu " + nameof(CisloCp))]
        [JsonProperty(PropertyName = "CisloCp")]
        public int? CisloCp { get; set; }
        /// <summary>
        /// Cislo orientacni
        /// </summary>
        /// <example>15</example>
        //[MaxLength(Constants.MaxDelkaCisOrientacni, ErrorMessage = "Překročena maximální délka hodnoty atributu " + nameof(CisloCo))]
        [JsonProperty(PropertyName = "CisloCo")]
        public int? CisloCo { get; set; }
        /// <summary>
        /// Pismeno cisla orientacniho
        /// </summary>
        /// <example>a</example>
        [JsonProperty(PropertyName = "PismenoCo")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string PismenoCo { get; set; }
        /// <summary>
        /// Identifikátor adresního místa (centr. registr)
        /// </summary>
        /// <example>156358</example>
        [JsonProperty(PropertyName = "IdCentralniReg")]
        public int? IdCentralniReg { get; set; }

        //
        // *** další atributy adresy (zatím nepoužívané)
        //
        /// <summary>
        /// Typ adresy (hodnota z atr. kod v číselníku TypAdresy)
        /// </summary>
        /// <example>Trvalá</example>
        [JsonProperty(PropertyName = "TypAdresy")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string TypAdresy { get; set; }
        /// <summary>
        /// Typ cisla domovniho
        /// </summary>
        /// <example>1</example>
        [JsonProperty(PropertyName = "TypCislaDomovniho")]
        public int? TypCislaDomovniho { get; set; }
        /// <summary>
        /// Městský obvod
        /// </summary>
        /// <example>Plzeň 1</example>
        [JsonProperty(PropertyName = "MestskyObvod")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string MestskyObvod { get; set; }
        /// <summary>
        /// Okres
        /// </summary>
        /// <example>Plzeň město</example>
        [JsonProperty(PropertyName = "Okres")]
        [JsonConverter(typeof(NullToEmptyStringConverter))]
        public string Okres { get; set; }
        /// <summary>
        /// Stav Adresy 
        /// </summary>
        /// <example>1</example>
        [JsonProperty(PropertyName = "StavAdresy")]
        public int? StavAdresy { get; set; }
    }

    /// <summary>
    /// EN: Null value handling for string properties.
    /// </summary>
    internal class NullToEmptyStringConverter : JsonConverter
    {
        public override bool CanConvert(Type objectType)
        {
            return true;
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            var value = existingValue ?? reader.Value;
            return objectType == typeof(string) ? value ?? string.Empty : value;
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            if (string.IsNullOrEmpty(value as string))
                writer.WriteValue(string.Empty);
            else
                writer.WriteValue(value);
        }
    }

}
